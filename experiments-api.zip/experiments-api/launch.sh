#!/usr/bin/env bash

cd $APP_HOME

bundle exec rake db:migrate RAILS_ENV=$RAILS_ENV

if [[ $? != 0 ]]; then
  echo "Failed to migrate. Exiting."
  exit 1
fi

echo "DB migrate done!"

bundle exec unicorn -c config/unicorn.rb -E $RAILS_ENV