require 'swagger_helper'

RSpec.describe 'api/v1/services', type: :request do

  path '/api/v1/services' do

    post('create service') do
      response(200, 'successful') do

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end
  end

  path '/api/v1/services/{service_id}' do
    # You'll want to customize the parameter types...
    parameter name: 'service_id', in: :path, type: :string, description: 'service_id'

    get('get service') do
      response(200, 'successful') do
        let(:service_id) { '123' }

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end
  end

  path '/api/v1/services/{service_id}/activate' do
    # You'll want to customize the parameter types...
    parameter name: 'service_id', in: :path, type: :string, description: 'service_id'

    put('activate service') do
      response(200, 'successful') do
        let(:service_id) { '123' }

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end
  end

  path '/api/v1/services/{service_id}/deactivate' do
    # You'll want to customize the parameter types...
    parameter name: 'service_id', in: :path, type: :string, description: 'service_id'

    put('deactivate service') do
      response(200, 'successful') do
        let(:service_id) { '123' }

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end
  end
end
