require 'swagger_helper'

RSpec.describe 'api/v1/experiments', type: :request do

  path '/api/v1/experiments' do

    get('list experiment') do
      response(200, 'successful') do

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end

    post('create experiment') do
      response(200, 'successful') do

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end
  end

  path '/api/v1/experiments/{experiment_id}' do
    # You'll want to customize the parameter types...
    parameter name: 'experiment_id', in: :path, type: :string, description: 'experiment_id'

    get('get experiment') do
      response(200, 'successful') do
        let(:experiment_id) { '123' }

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end
  end

  path '/api/v1/experiments/{experiment_id}/activate' do
    # You'll want to customize the parameter types...
    parameter name: 'experiment_id', in: :path, type: :string, description: 'experiment_id'

    put('activate experiment') do
      response(200, 'successful') do
        let(:experiment_id) { '123' }

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end
  end

  path '/api/v1/experiments/{experiment_id}/deactivate' do
    # You'll want to customize the parameter types...
    parameter name: 'experiment_id', in: :path, type: :string, description: 'experiment_id'

    put('deactivate experiment') do
      response(200, 'successful') do
        let(:experiment_id) { '123' }

        after do |example|
          example.metadata[:response][:content] = {
            'application/json' => {
              example: JSON.parse(response.body, symbolize_names: true)
            }
          }
        end
        run_test!
      end
    end
  end
end
