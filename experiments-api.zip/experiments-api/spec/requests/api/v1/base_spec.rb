require 'swagger_helper'

RSpec.describe 'api/v1/base', type: :request do
end
