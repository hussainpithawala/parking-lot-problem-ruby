RSpec.describe 'APIs to interact with experiments' do
  before(:each) do
    post '/api/v1/services', params: {name: "test-service #{SecureRandom.uuid}", active: true}, as: :json
    @service_id = JSON.parse(response.body)['data']['service']['id']
  end

  it 'Should raise an error if service id is not provided' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    post '/api/v1/experiments', params: payload, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:bad_request)

    expect(JSON.parse(response.body)['errors']['code']).to eq('service_id_missing')
  end
  
  it 'Should allow creating an experiment' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:created)

    experiment = JSON.parse(response.body)['data']['experiment']

    expect(experiment['service_id']).to eq(@service_id)
    expect(experiment['name']).to eq(payload['name'])

    # Ensure the buckets were created
    buckets = Hash[
      experiment['experiment_buckets'].map { |bucket|
        [bucket['bucket_name'], bucket['percentage_distribution']]
      }
    ]

    expect(buckets.keys.sort).to eq(['a', 'b'])
    expect(buckets['a']).to eq(30)
    expect(buckets['b']).to eq(70)

    # Ensure termination was created
    termination = experiment['experiment_termination']
    expect(termination['termination_type']).to eq('SampleCount')
    expect(termination['termination_value']).to eq('1000')
  end

  it 'Should not allow creating an experiment with duplicate name' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:bad_request)

    errors = JSON.parse(response.body)['errors']

    expect(errors['code']).to eq('duplicate_experiment_name')
  end

  it 'Should allow creating a request with termination type datetime' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)

    payload['experiment_termination']['termination_type'] = 'DateTime'
    payload['experiment_termination']['termination_value'] = '2019-06-25 07:30:00'

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:created)
  end

  it 'Should allow activating and deactiving an experiment' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    experiment_id = JSON.parse(response.body)['data']['experiment']['id']

    put "/api/v1/experiments/#{experiment_id}/activate", headers: {'Service-ID' => @service_id}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:ok)

    get "/api/v1/experiments/#{experiment_id}", headers: {'Service-ID' => @service_id}, as: :json

    expect(JSON.parse(response.body)['data']['experiment']['active']).to be_truthy

    put "/api/v1/experiments/#{experiment_id}/deactivate", headers: {'Service-ID' => @service_id}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:ok)

    get "/api/v1/experiments/#{experiment_id}", headers: {'Service-ID' => @service_id}, as: :json

    expect(JSON.parse(response.body)['data']['experiment']['active']).to be_falsy
  end

  it 'Should not allow creating experiment for inactive service' do
    put "/api/v1/services/#{@service_id}/deactivate", as: :json

    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:precondition_failed)
    expect(JSON.parse(response.body)['errors']['code']).to eq('service_inactive')
  end

  it 'Should not allow creating experiment for non-existent service' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => 'does-not-exist'}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:not_found)
    expect(JSON.parse(response.body)['errors']['code']).to eq('service_not_found')
  end

  it 'Should only list active experiments' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    active_experiment = JSON.parse(response.body)['data']['experiment']['id']

    put "/api/v1/experiments/#{active_experiment}/activate", headers: {'Service-ID' => @service_id}, as: :json

    payload['name'] = 'Inactive experiment'
    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    inactive_experiment = JSON.parse(response.body)['data']['experiment']['id']

    payload['name'] = 'Future experiment'
    payload['scheduled_start_date'] = (DateTime.now.in_time_zone(TIME_ZONE) + 1.day).strftime '%Y-%m-%d %I:%M:%S'
    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    future_experiment = JSON.parse(response.body)['data']['experiment']['id']

    get '/api/v1/experiments', headers: {'Service-ID' => @service_id}, as: :json

    experiments = JSON.parse(response.body)['data']['experiments'].map { |experiment| experiment['id'] }

    expect(experiments.include? active_experiment).to be_truthy
    expect(experiments.include? inactive_experiment).to be_falsy
    expect(experiments.include? future_experiment).to be_falsy

    Timecop.freeze(DateTime.now + 2.days) do
      get '/api/v1/experiments?active_only=false', headers: {'Service-ID' => @service_id}, as: :json

      experiments = JSON.parse(response.body)['data']['experiments'].map { |experiment| experiment['id'] }

      expect(experiments.include? active_experiment).to be_truthy
      expect(experiments.include? inactive_experiment).to be_truthy
      expect(experiments.include? future_experiment).to be_truthy
    end
  end

  it 'Should validate the types of termination type and value' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    payload['experiment_termination']['termination_type'] = 'SampleCount'
    payload['experiment_termination']['termination_value'] = 'string'

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:bad_request)

    expect(JSON.parse(response.body)['errors']['code']).to eq('invalid_schema')
    expect(JSON.parse(response.body)['errors']['details']['mismatches'][0]['name']).to eq('termination_value')

    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    payload['experiment_termination']['termination_type'] = 'DateTime'
    payload['experiment_termination']['termination_value'] = 'string'

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:bad_request)

    expect(JSON.parse(response.body)['errors']['code']).to eq('invalid_schema')
    expect(JSON.parse(response.body)['errors']['details']['mismatches'][0]['name']).to eq('termination_value')
  end

  it 'Should not allow activating an experiment after termination condition is reached' do
    termination_date = (DateTime.now + 1.day).in_time_zone(TIME_ZONE)

    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    payload['experiment_termination']['termination_type'] = 'DateTime'
    payload['experiment_termination']['termination_value'] = termination_date.strftime '%Y-%m-%d %I:%M:%S'

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    experiment_id = JSON.parse(response.body)['data']['experiment']['id']

    Timecop.freeze(termination_date + 1.second) do
      put "/api/v1/experiments/#{experiment_id}/activate", headers: {'Service-ID' => @service_id}, as: :json

      expect(response).to have_http_status(:precondition_failed)
    end
  end
end
