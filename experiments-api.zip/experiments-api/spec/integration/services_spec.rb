RSpec.describe 'APIs to interact with services' do
  it 'Should allow creating a service' do
    service_name = "test-service #{SecureRandom.uuid}"
    post '/api/v1/services', params: {name: service_name, active: true}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:created)

    service = JSON.parse(response.body)['data']['service']

    expect(service['active']).to be_truthy

    get "/api/v1/services/#{service['id']}"

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:ok)

    service = JSON.parse(response.body)['data']['service']

    expect(service['name']).to eq(service_name)
    expect(service['active']).to be_truthy
  end

  it 'Should not allow creating a service with name of an existing service' do
    service_name = "test-service #{SecureRandom.uuid}"
    post '/api/v1/services', params: {name: service_name, active: true}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:created)

    post '/api/v1/services', params: {name: service_name, active: true}, as: :json

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:bad_request)

    errors = JSON.parse(response.body)['errors']

    expect(errors['code']).to eq('duplicate_service_name')
  end
  
  it 'Should allow activating and deactiving a service' do
    post '/api/v1/services', params: {name: "test-service #{SecureRandom.uuid}", active: true}, as: :json
    service = JSON.parse(response.body)['data']['service']

    put "/api/v1/services/#{service['id']}/deactivate"

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:ok)

    service = JSON.parse(response.body)['data']['service']
    expect(service['active']).to be_falsy

    put "/api/v1/services/#{service['id']}/activate"

    expect(response.content_type).to eq('application/json')
    expect(response).to have_http_status(:ok)

    service = JSON.parse(response.body)['data']['service']
    expect(service['active']).to be_truthy
  end

  it 'Should correctly report schema errors request body' do
    post '/api/v1/services', params: {name: 1, active: true}, as: :json

    errors = JSON.parse(response.body)['errors']

    expect(errors['code']).to eq('invalid_schema')
    expect(errors['details']['mismatches']).to eq([{'actual'=>'integer', 'expected'=>'string', 'name'=>'name', 'path'=>''}])
  end

  it 'Should correctly report schema errors request body' do
    post '/api/v1/services', params: {name: 1, active: true}, as: :json

    errors = JSON.parse(response.body)['errors']

    expect(errors['code']).to eq('invalid_schema')
    expect(errors['details']['mismatches']).to eq([{'actual'=>'integer', 'expected'=>'string', 'name'=>'name', 'path'=>''}])
  end

end
