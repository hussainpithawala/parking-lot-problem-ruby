RSpec.describe 'APIs to interact with sampled buckets' do
  before(:each) do
    post '/api/v1/services', params: {name: "test-service #{SecureRandom.uuid}", active: true}, as: :json
    @service_id = JSON.parse(response.body)['data']['service']['id']
  end

  it 'Sampling same data for more than once should return the same allocated bucket' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json

    experiment = JSON.parse(response.body)['data']['experiment']
    put "/api/v1/experiments/#{experiment['id']}/activate", headers: {'Service-ID' => @service_id}, as: :json

    payload = {'sampled_entity' => 'User', 'sampled_value' => "some-id"}
    post "/api/v1/experiments/#{experiment['id']}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json

    sample = JSON.parse(response.body)['data']['bucketed_sample']

    expect(['a', 'b'].include?(sample['allocated_bucket'])).to be_truthy

    post "/api/v1/experiments/#{experiment['id']}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json
    expect(JSON.parse(response.body)['data']['bucketed_sample']['id']).to eq(sample['id'])

  end

  it 'Should allow marking a sample as complete' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    experiment_id = JSON.parse(response.body)['data']['experiment']['id']
    put "/api/v1/experiments/#{experiment_id}/activate", headers: {'Service-ID' => @service_id}, as: :json

    payload = {'sampled_entity' => 'User', 'sampled_value' => "some-value-other-value", 'complete' => true}
    post "/api/v1/experiments/#{experiment_id}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json

    sample_id = JSON.parse(response.body)['data']['bucketed_sample']['id']
    get "/api/v1/experiments/#{experiment_id}/bucketed_samples/#{sample_id}", headers: {'Service-ID' => @service_id}, as: :json

    expect(JSON.parse(response.body)['data']['bucketed_sample']['complete']).to be_truthy

    payload = {'sampled_entity' => 'User', 'sampled_value' => "some-value"}
    post "/api/v1/experiments/#{experiment_id}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json

    sample_id = JSON.parse(response.body)['data']['bucketed_sample']['id']
    get "/api/v1/experiments/#{experiment_id}/bucketed_samples/#{sample_id}", headers: {'Service-ID' => @service_id}, as: :json

    expect(JSON.parse(response.body)['data']['bucketed_sample']['complete']).to be_falsy

    put "/api/v1/experiments/#{experiment_id}/bucketed_samples/#{sample_id}/complete", headers: {'Service-ID' => @service_id}, as: :json

    expect(response).to have_http_status(:ok)
    expect(JSON.parse(response.body)['data']['bucketed_sample']['complete']).to be_truthy
  end

  it 'Should allow listing all the bucketed samples' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    experiment = JSON.parse(response.body)['data']['experiment']

    put "/api/v1/experiments/#{experiment['id']}/activate", headers: {'Service-ID' => @service_id}, as: :json

    for n in (0..4) do
      payload = {'sampled_entity' => 'User', 'sampled_value' => "id-#{n}", 'complete' => true}
      post "/api/v1/experiments/#{experiment['id']}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json

      expect(response).to have_http_status(:created)
    end

    get "/api/v1/experiments/#{experiment['id']}/bucketed_samples", headers: {'Service-ID' => @service_id}, as: :json
    expect(response).to have_http_status(:ok)

    bucketed_samples = JSON.parse(response.body)['data']['bucketed_samples']
    expect(bucketed_samples.length).to eq(5)

    bucketed_samples.each do |bucket|
      expect(bucket['sampled_entity']).to eq('User')
      expect(bucket['complete']).to be_truthy
      expect(bucket['sampled_value']).to match(/id-[0-9]/)
    end
  end

  # TODO possibly flaky
  it 'Should allow bucketing a sample for n > SampleCount till distribution matches' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    payload['experiment_termination']['termination_value'] = 10

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    experiment = JSON.parse(response.body)['data']['experiment']
    put "/api/v1/experiments/#{experiment['id']}/activate", headers: {'Service-ID' => @service_id}, as: :json

    desired_distribution = Hash[
      experiment['experiment_buckets'].map { |bucket|
        [bucket['bucket_name'], bucket['percentage_distribution']]
      }
    ]

    buckets = Hash[
      desired_distribution.keys.map { |bucket| [bucket, 0] }
    ]

    for n in (0..100) do
      payload = {'sampled_entity' => 'User', 'sampled_value' => SecureRandom.uuid, 'complete' => true}
      post "/api/v1/experiments/#{experiment['id']}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json

      expect(response).to have_http_status(:created) | have_http_status(:precondition_failed)

      if response.status == 201
        buckets[JSON.parse(response.body)['data']['bucketed_sample']['allocated_bucket']] += 1
      else
        break
      end
    end

    # Ensure the distribution is within 5% of the configured split
    buckets.keys.all? do |bucket|
      distribution = buckets[bucket] * 100.0 / n
      expect((desired_distribution[bucket] - distribution).abs <= 5).to be_truthy
    end
  end

  it 'Should allow bucketing a sample till the provided date time' do
    termination_date = (DateTime.now + 30.days).in_time_zone(TIME_ZONE)

    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)
    payload['experiment_termination']['termination_type'] = 'DateTime'
    payload['experiment_termination']['termination_value'] = termination_date.strftime '%Y-%m-%d %I:%M:%S'

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    experiment = JSON.parse(response.body)['data']['experiment']

    put "/api/v1/experiments/#{experiment['id']}/activate", headers: {'Service-ID' => @service_id}, as: :json

    for n in (0..10) do
      payload = {'sampled_entity' => 'User', 'sampled_value' => SecureRandom.uuid}
      post "/api/v1/experiments/#{experiment['id']}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json

      expect(response).to have_http_status(:created)
    end

    Timecop.freeze(termination_date + 1.second) do
      payload = {'sampled_entity' => 'User', 'sampled_value' => SecureRandom.uuid}
      post "/api/v1/experiments/#{experiment['id']}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json

      expect(response).to have_http_status(:precondition_failed)
    end
  end

  it 'Should not allow marking a sample as complete for an inactive experiment, without an error' do
    payload = JSON.parse(file_fixture('create_experiment_payload.json').read)

    post '/api/v1/experiments', params: payload, headers: {'Service-ID' => @service_id}, as: :json
    experiment = JSON.parse(response.body)['data']['experiment']

    put "/api/v1/experiments/#{experiment['id']}/activate", headers: {'Service-ID' => @service_id}, as: :json

    payload = {'sampled_entity' => 'User', 'sampled_value' => 'some-id'}
    post "/api/v1/experiments/#{experiment['id']}/bucketed_samples", params: payload, headers: {'Service-ID' => @service_id}, as: :json

    bucketed_sample = JSON.parse(response.body)['data']['bucketed_sample']

    put "/api/v1/experiments/#{experiment['id']}/deactivate", headers: {'Service-ID' => @service_id}, as: :json

    put "/api/v1/experiments/#{experiment['id']}/bucketed_samples/#{bucketed_sample['id']}/complete", params: payload, headers: {'Service-ID' => @service_id}, as: :json

    expect(response).to have_http_status(:precondition_failed)
    expect(JSON.parse(response.body)['errors']['code']).to eq('experiment_terminated')
  end
end
