class EventPublisher60af94a2
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:60af94a2', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
