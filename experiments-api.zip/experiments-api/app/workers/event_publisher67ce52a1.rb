class EventPublisher67ce52a1
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:67ce52a1', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
