class EventPublisher20fb96c8
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:20fb96c8', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
