class EventPublisherbf316a57
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:bf316a57', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
