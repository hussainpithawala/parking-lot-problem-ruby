class EventPublisher0573d06f
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:0573d06f', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
