class EventPublisher873b1a0f
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:873b1a0f', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
