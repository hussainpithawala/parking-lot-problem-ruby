class EventPublisherfea71e29
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:fea71e29', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
