class EventPublisherb1d2a320
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:b1d2a320', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
