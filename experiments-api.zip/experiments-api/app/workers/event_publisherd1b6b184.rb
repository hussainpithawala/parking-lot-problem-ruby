class EventPublisherd1b6b184
  include Sidekiq::Worker

  sidekiq_options queue: 'api_events:d1b6b184', backtrace: true, retry: false

  def perform(payload)
    service = BasePublisherService.new
    service.sync_send_message(payload)
  end
end
