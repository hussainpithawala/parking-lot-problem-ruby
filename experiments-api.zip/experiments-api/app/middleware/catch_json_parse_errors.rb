class CatchJsonParseErrors
  def initialize(app)
    @app = app
  end

  def call(env)
    begin
      @app.call(env)
    rescue ActionDispatch::Http::Parameters::ParseError => error
      if env['HTTP_ACCEPT'] =~ /application\/json/ or env['CONTENT_TYPE'] =~ /application\/json/
        error_output = "Invalid JSON. Please verify the JSON object."
        return [
            400, { "Content-Type" => "application/json" },
            [ { success: false,
                data: {

                },
                api_version: Api::V1::BaseController::API_VERSION,
                errors: [error_output] }.to_json ]
        ]
      else
        raise error
      end
    end
  end
end