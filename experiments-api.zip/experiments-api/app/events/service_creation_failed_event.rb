class ServiceCreationFailedEvent < BaseEvent
  VERSION = 1.0
  attr_reader :creation_parameters, :error_code

  def initialize(creation_parameters, error_code)
    super()
    @creation_parameters = creation_parameters
    @error_code = error_code
  end

  def populate_payload
    @payload = {
      creation_parameters: creation_parameters,
      error_code: error_code,
      version: VERSION
    }
  end
end