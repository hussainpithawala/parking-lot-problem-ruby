class BaseEvent
  include ActiveModel::Model

  BASE_EVENT_VERSION = 1.0

  attr_reader :publisher, :event_error_messages, :payload

  validates :publisher, presence: true

  validate do |base_event|
    event_error_messages.push('Payload needs to be a Hash') if not base_event.payload.instance_of?(Hash)
    event_error_messages.push('Payload cannot be empty') if base_event.payload.instance_of?(Hash) and base_event.payload.empty?
  end

  def initialize(publisher = nil)
    @publisher = publisher || BasePublisherService.new
    @event_error_messages = []
  end

  def publish(payload, partition_id = nil)
    set_event_payload(payload)

    validate_payload
    set_event_timestamp
    set_event_name
    set_event_id
    publish_payload(partition_id)

    EventResponse.new(self.event_error_messages, payload)
  end

  def set_event_timestamp
    return if event_error_messages.any?

    @payload[:event_timestamp] = DateTime.now
  end

  def set_event_name
    return if event_error_messages.any?

    @payload[:event_name] = self.class.to_s.demodulize.to_s
  end

  def set_event_id
    return if event_error_messages.any?

    @payload[:event_id] = SecureRandom.uuid
  end

  # Note
  # ---------------------------------------------------------------
  # Trigger is the method overridden by all subclasses.
  # Every event subclass needs to override the `populate_payload` method to customise
  # events.
  #
  def trigger!(partition_id = nil)
    populate_payload
    publish_response = publish(payload, partition_id)

    if not publish_response.success?
      Rails.logger.error({ error: "#{self.class.to_s.demodulize} failed to publish",
                           response: publish_response.as_json,
                           file: 'app/services/events/base_event.rb' })
    else
      Rails.logger.info({ message: "#{self.class.to_s.demodulize} successfully published." })
    end
    publish_response
  end

  private

  def publish_payload(partition_id)
    return if event_error_messages.any?

    publisher.send_message(payload, partition_id)
  end

  def populate_payload
    raise 'The extending class needs to implement a method to populate payload'
  end

  def set_event_payload(event_payload)
    @payload = event_payload
  end

  def validate_payload
    event_error_messages.push(self.errors).flatten! if not self.valid?
  end
end

class EventResponse
  attr_reader :event_error_messages, :success, :payload

  def initialize(event_error_messages, payload)
    @event_error_messages = event_error_messages
    @payload = payload
    @success = event_error_messages.any? ? false : true
  end

  def success?
    success
  end
end
