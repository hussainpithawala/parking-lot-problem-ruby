class SampleMarkCompletionFailedEvent < BaseEvent
  VERSION = 1.0
  attr_reader :bucketed_sample, :error_code

  def initialize(bucketed_sample, error_code)
    super()
    @bucketed_sample = bucketed_sample
    @error_code = error_code
  end

  def populate_payload
    @payload = {
      bucketed_sample: bucketed_sample,
      experiment: bucketed_sample.experiment,
      service: bucketed_sample.experiment.service,
      error_code: error_code,
      version: VERSION
    }
  end
end