class SampleBucketedEvent < BaseEvent
  VERSION = 1.0
  attr_reader :bucketed_sample

  def initialize(bucketed_sample)
    super()
    @bucketed_sample = bucketed_sample
  end

  def populate_payload
    @payload = {
      bucketed_sample: bucketed_sample,
      experiment: bucketed_sample.experiment,
      service: bucketed_sample.experiment.service,
      version: VERSION
    }
  end
end