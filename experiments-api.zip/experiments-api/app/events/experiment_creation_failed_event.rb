class ExperimentCreationFailedEvent < BaseEvent
  VERSION = 1.0
  attr_reader :creation_params, :error_code

  def initialize(creation_params, error_code)
    super()
    @creation_params = creation_params
    @error_code = error_code
  end

  def populate_payload
    @creation_params = {
      creation_params: creation_params,
      error_code: error_code,
      version: VERSION
    }
  end
end