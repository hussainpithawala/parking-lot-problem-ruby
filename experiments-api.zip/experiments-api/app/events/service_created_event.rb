class ServiceCreatedEvent < BaseEvent
  VERSION = 1.0
  attr_reader :service

  def initialize(service)
    super()
    @service = service
  end

  def populate_payload
    @payload = {
      service: service,
      version: VERSION
    }
  end
end