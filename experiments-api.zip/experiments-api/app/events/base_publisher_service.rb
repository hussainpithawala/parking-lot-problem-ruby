class BasePublisherService
  def initialize() end

  def send_message(payload, partition_id = nil)
    retry_count = 0
    begin
      retry_count += 1
      if partition_id.present?
        publisher_klass = determine_publisher_klass(partition_id)
        publisher_klass.perform_async(payload.to_json)
      else
        EventPublisher.perform_async(payload.to_json)
      end
    rescue Redis::CommandError => e
      Rails.logger.error({ error: "[Redis Error handled]: #{e.message} \n #{e.backtrace}", file: 'app/services/events/publisher_services/base_publisher_service.rb' })
      reconnect_redis
      reconnect_sidekiq
      retry if retry_count < 2
    rescue Errno::ECONNRESET, ConnectionPool::PoolShuttingDownError => e
      Rails.logger.error({ error: "[Redis Error handled]: #{e.message} \n #{e.backtrace}", file: 'app/services/events/publisher_services/base_publisher_service.rb' })
      initialize_redis_connection
      initialize_sidekiq_connection
      retry if retry_count < 2
    rescue => e
      Rails.logger.error({ error: "[Redis Error]: #{e.message} \n #{e.backtrace}", file: 'app/services/events/publisher_services/base_publisher_service.rb', payload: payload.as_json })
    end
  end

  # Todo:
  # --------
  # Migrate this to use Excon instead of native HTTP client.
  def sync_send_message(payload)
    begin
      url = ENV['EVENT_PUBLISHER_URL']
      uri = URI.parse(url)
      http = Net::HTTP.new(uri.host, uri.port)
      req = Net::HTTP::Post.new(uri.path, { 'content-type' => 'application/json' })
      req.body = payload
      res = http.request(req)
      Rails.logger.info({ message: "[EventPublished] #{res.code} #{res.message} #{res.body}" })
    rescue => e
      Rails.logger.error({ error: "[EventPublisher Error]: #{e.message} \n #{e.backtrace}", file: 'app/services/events/publisher_services/base_publisher_service.rb' })
      Rails.logger.error(payload)
    end
  end

  def determine_publisher_klass(partition_id)
    sha1 = Digest::SHA1.hexdigest(partition_id)
    partition_id_as_int = Integer("0x#{sha1}")
    node_index = (Bisect.bisect_left(EVENT_PUBLISHER_QUEUE_CONTINUUM, partition_id_as_int, 0, EVENT_PUBLISHER_QUEUE_CONTINUUM.size - 1)) - 1
    queue_integer = EVENT_PUBLISHER_QUEUE_CONTINUUM[node_index]
    queue_uuid = QUEUE_INTEGER_TO_IDS[queue_integer]
    klass_name_postfix = queue_uuid.split('-')[0]
    "EventPublisher#{klass_name_postfix}".constantize
  end
end