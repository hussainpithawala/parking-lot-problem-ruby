class SampleBucketingFailedEvent < BaseEvent
  VERSION = 1.0
  attr_reader :sampling_params, :error_code

  def initialize(sampling_params, error_code)
    super()
    @sampling_params = sampling_params
    @error_code = error_code
  end

  def populate_payload
    @payload = {
      sampling_params: sampling_params,
      error_code: error_code,
      version: VERSION
    }
  end
end