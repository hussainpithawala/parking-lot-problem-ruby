class ExperimentActivatedEvent < BaseEvent
  VERSION = 1.0
  attr_reader :experiment

  def initialize(experiment)
    super()
    @experiment = experiment
  end

  def populate_payload
    @payload = {
      experiment: experiment,
      service: experiment.service,
      version: VERSION
    }
  end
end
