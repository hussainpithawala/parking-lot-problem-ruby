class WelcomeController < ApplicationController

  def index
    render json: {
        success: true,
        data: {
            message: "Hello from Experiments - API"
        },
        api_version: 1.0
    }, status: :ok
  end

  def check
    render json: {
        success: true,
        data: {
            message: "Hello from Experiments - API",
            timestamp: UtilService.local_time_now.to_i
        },
        api_version: 1.0
    }, status: :ok
  end
end