class Api::V1::ServicesController < Api::V1::BaseController
  @@creation_request_schema = {
    'required' => ['name'],
    'properties' => {
      'name' => {
        'type' => 'string'
      },
      'active' => {
        'type' => 'boolean',
        'default' => true
      }
    },
    'additionalProperties' => false
  }

  def create
    permitted_params = params.permit(
      :name, :active
    )

    validation = RequestValidators::RequestValidatorService.new(
      @@creation_request_schema, permitted_params.to_hash
    ).validate_schema

    if !validation.success?
      render_api_error(
        code: validation.error_code,
        message: validation.errors,
        details: validation.error_details,
        status: :bad_request
      )

      return
    end

    response = Core::ServiceApi.new.create(params[:name], active: params[:active])

    if response.success?
      return render_api_response(
        { service: response.service }, status: :created
      )
    else
      render_api_error(
        code: response.error_code, message: response.errors, status: :bad_request
      )
    end
  end

  def get
    response = Core::ServiceApi.new.get(params[:service_id])

    if response.success?
      render_api_response({ service: response.service })

    else
      status = :not_found if response.error_code == :service_not_found

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )

    end
  end

  def list
    response = Core::ServiceApi.new.list
    render_api_response({ services: response.service })
  end
  def activate
    response = Core::ServiceApi.new.activate(params[:service_id])

    if response.success?
      render_api_response({ service: response.service })

    else
      status = :not_found if response.error_code == :service_not_found

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )
    end
  end

  def deactivate
    response = Core::ServiceApi.new.deactivate(params[:service_id])

    if response.success?
      render_api_response({ service: response.service })

    else
      status = :not_found if response.error_code == :service_not_found

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )
    end
  end
end
