class Api::V1::BucketedSamplesController < Api::V1::BaseController
  before_action :extract_service_id

  @@creation_request_schema = schema = {
    'required' => ['experiment_id', 'sampled_entity', 'sampled_value'],
    'properties' => {
      'service_id' => {
        'type' => 'string'
      },
      'experiment_id' => {
        'type' => 'string'
      },
      'sampled_entity' => {
        'type' => 'string'
      },
      'sampled_value' => {
        'type' => 'string'
      },
      'complete' => {
        'type' => 'boolean',
        'default' => false
      }
    },
    'additionalProperties' => false
  }

  def create
    permitted_params = params.permit(
      :service_id, :experiment_id, :sampled_entity, :sampled_value, :complete
    )

    validation = RequestValidators::RequestValidatorService.new(
      @@creation_request_schema, permitted_params.to_hash
    ).validate_schema

    if !validation.success?
      render_api_error(
        code: validation.error_code,
        message: validation.errors,
        details: validation.error_details,
        status: :bad_request
      )

      return
    end

    response = Core::BucketedSampleApi.new.create(permitted_params)

    if response.success?
      status = :ok
      status = :created if response.is_new

      render_api_response(
        {
          bucketed_sample: response.bucketed_sample
        },
        status: status
      )

    else
      status = :not_found if response.error_code == :service_not_found
      status = :not_found if response.error_code == :experiment_not_found
      status = :precondition_failed if response.error_code == :experiment_inactive
      status = :precondition_failed if response.error_code == :experiment_terminated

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )

    end

  end

  def get
    response = Core::BucketedSampleApi.new.get(
      params[:service_id], params[:experiment_id], params[:bucketed_sample_id]
    )

    if response.success?
      render_api_response({
        bucketed_sample: response.bucketed_sample
      })

    else
      status = :not_found if response.error_code == :service_not_found
      status = :not_found if response.error_code == :experiment_not_found
      status = :not_found if response.error_code == :bucketed_sample_not_found

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )
    end
  end

  def list
    response = Core::BucketedSampleApi.new.list(
      params[:service_id], params[:experiment_id]
    )

    if response.success?
      render_api_response({
        bucketed_samples: response.bucketed_samples
      })

    else
      status = :not_found if response.error_code == :service_not_found
      status = :not_found if response.error_code == :experiment_not_found

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )
    end
  end

  def complete
    response = Core::BucketedSampleApi.new.complete(
      params[:service_id], params[:experiment_id], params[:bucketed_sample_id]
    )

    if response.success?
      render_api_response({
        bucketed_sample: response.bucketed_sample
      })

    else
      status = :not_found if response.error_code == :service_not_found
      status = :not_found if response.error_code == :experiment_not_found
      status = :not_found if response.error_code == :bucketed_sample_not_found
      status = :precondition_failed if response.error_code == :experiment_terminated

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )
    end
  end
end
