class Api::V1::BaseController < ApplicationController
  wrap_parameters false
  API_VERSION = 1.0

  rescue_from StandardError, with: :render_unhandled_exception

  def extract_service_id
    if request.headers.key? 'Service-ID'
      params[:service_id] = request.headers['Service-ID']
    else
      render_api_error(
        code: :service_id_missing,
        message: "Please pass service_id as 'Service-ID' header",
        status: :bad_request
      )
    end
  end

  def render_api_response(data, include: [], status: :ok)
    body = {
      api_version: API_VERSION,
      success: true,
      data: data,
      errors: {
        code: nil,
        message: nil
      }
    }

    render json: body, status: status, include: include
  end

  def render_api_error(code: :internal_server_error, message: 'Internal Server error', status: 500, details: nil)
    body = {
      api_version: API_VERSION,
      success: false,
      data: {},
      errors: {
        code: code,
        message: message,
        details: details
      }
    }

    render json: body, status: (status || 500)
  end

  def render_unhandled_exception(exception)
    Rails.logger.error("[ERROR] #{exception.message}")
    Rails.logger.error(exception.backtrace.join("\n"))

    raise exception if Rails.env.test? or (RAISE_DEVELOPMENT_ERRORS == 'true')
    Rails.logger exception

    render_api_error
  end

  def add_cors_headers(params = {})
    headers['Access-Control-Allow-Origin'] = fetch_whitelisted_domains
    headers['Access-Control-Allow-Methods'] = 'POST, PUT, DELETE, GET, OPTIONS'
    headers['Access-Control-Request-Method'] = '*'
    headers['Access-Control-Allow-Headers'] = headers_list
  end

  def headers_list
    [
      'Origin',
      'X-Requested-With',
      'Content-Type',
      'Accept',
      'Authorization',
      'CLIENT-ID',
      'Os-Name',
      'Os-Version',
      'Browser-Name',
      'Browser-Version',
      'On-Mobile',
      'User-Agent',
      'Screen-Resolution',
      'Cookies-Enabled',
      'No-Of-Plugins',
      'Lat-Long',
      'Timezone',
      'Device-Pixel-Ratio',
      'X-Real-IP',
      'Language',
      'Plugin-Details'
    ].join(', ')
  end

  def numerical?(string)
    /\A\d+\z/.match(string.to_s)
  end

  def preflight
    headers['Access-Control-Allow-Origin'] = fetch_whitelisted_domains
    headers['Access-Control-Allow-Methods'] = 'POST, GET, PUT, DELETE, OPTIONS'
    headers['Access-Control-Allow-Headers'] = headers_list
    headers['Access-Control-Max-Age'] = '-1'
    render json: ''
  end

  def fetch_whitelisted_domains
    trusted_hosts = ["#{APP_HOST}"]

    if Rails.env.development? or Rails.env.staging? or Rails.env.test? or Rails.env.qa?
      return '*'
    end

    if Rails.env.production? and trusted_hosts.include?(request.headers['origin'])
      request.headers['origin']
    else
      APP_HOST
    end
  end

  def add_allow_credentials_headers
    response.headers['Access-Control-Allow-Credentials'] = 'true'
  end
end
