class Api::V1::ExperimentsController < Api::V1::BaseController
  before_action :extract_service_id

  @@creation_request_schema = {
    'required' => ['service_id', 'name', 'experiment_buckets', 'experiment_termination'],
    'properties' => {
      'service_id' => {
        'type' => 'string'
      },
      'name' => {
        'type' => 'string'
      },
      'active' => {
        'type' => 'boolean',
        'default' => false
      },
      'experiment_buckets' => {
        'type' => 'array',
        'items' => {
          'type' => 'object',
          'required' => ['bucket_name', 'percentage_distribution'],
          'properties' => {
            'bucket_name' => {
              'type' => 'string'
            },
            'percentage_distribution' => {
              'type' => 'integer'
            },
            'additionalProperties' => false
          }
        }
      },
      'experiment_termination' => {
        'type' => 'object',
        'required' => ['termination_type', 'termination_value'],
        'properties' => {
          'termination_type' => {
            'type' => 'string',
            'enum' => ['SampleCount', 'DateTime']
          },
          'termination_value' => {
            # Additional validations are done at model level
            'type' => ['string', 'integer']
          }
        },
        'additionalProperties' => false
      },
      'experiment_sampling_criteria' => {
        'type' => 'array',
        'items' => {
          'type' => 'object',
          'required' => ['sampling_model', 'sampling_attribute'],
          'properties' => {
            'sampling_model' => {
              'type' => 'string'
            },
            'sampling_attribute' => {
              'type' => 'string'
            },
            'experiment_sampling_conditions' => {
              'type' => 'array',
              'items' => {
                'type' => 'object',
                'required' => ['model', 'property', 'value', 'value_type', 'condition'],
                'properties' => {
                  'model' => {
                    'type' => 'string'
                  },
                  'property' => {
                    'type' => 'string'
                  },
                  'value' => {
                    'type' => 'string'
                  },
                  'value_type' => {
                    'type' => 'string'
                  },
                  'condition' => {
                    'type' => 'string'
                  }
                },
                'additionalProperties' => false
              },
              'default' => []
            }
          },
          'additionalProperties' => false
        },
        'default' => []

      },
      'scheduled_start_date' => {
        'type' => 'date-time',
        'default' => nil
      }
    },
    'additionalProperties' => false
  }

  def create
    validation = validate_create_params

    if !validation.success?
      render_api_error(
        code: validation.error_code,
        message: validation.errors,
        details: validation.error_details,
        status: :bad_request
      )

      return
    end

    response = Core::ExperimentApi.new.create(validation.parameters)

    if response.success?
      render_api_response(
        {
          experiment: serialize_experiment(response.experiment)
        },
        status: :created
      )

    else
      status = :not_found if response.error_code == :service_not_found
      status = :bad_request if response.error_code == :duplicate_experiment_name
      status = :precondition_failed if response.error_code == :service_inactive

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )

    end
  end

  def get
    response = Core::ExperimentApi.new.get(params[:service_id], params[:experiment_id])

    if response.success?
      render_api_response(
        {
          experiment: serialize_experiment(response.experiment)
        }
      )

    else
      status = :not_found if response.error_code == :service_not_found
      status = :not_found if response.error_code == :experiment_not_found

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )
    end
  end

  def list
    params[:active_only] ||= 'true'
    active_only = ActiveRecord::Type::Boolean.new.deserialize(params[:active_only])

    response = Core::ExperimentApi.new.list(params[:service_id], active_only: active_only)

    if response.success?
      render_api_response(
        {
          experiments: response.experiments.map do |experiment|
            serialize_experiment experiment
          end
        }
      )

    else
      status = :not_found if response.error_code == :service_not_found

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )

    end
  end

  def activate
    response = Core::ExperimentApi.new.activate(params[:service_id], params[:experiment_id])

    if response.success?
      render_api_response(
        {
          experiment: response.experiment
        }
      )

    else
      status = :not_found if response.error_code == :experiment_not_found
      status = :not_found if response.error_code == :service_not_found
      status = :precondition_failed if response.error_code == :experiment_terminated

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )

    end
  end

  def deactivate
    response = Core::ExperimentApi.new.deactivate(params[:service_id], params[:experiment_id])

    if response.success?
      render_api_response(
        {
          experiment: response.experiment
        }
      )

    else
      status = :not_found if response.error_code == :experiment_not_found
      status = :not_found if response.error_code == :service_not_found

      render_api_error(
        code: response.error_code, message: response.errors, status: status
      )

    end
  end

  def serialize_experiment experiment
    {
      id: experiment.id,
      service_id: experiment.service_id,
      name: experiment.name,
      active: experiment.active,
      experiment_buckets: experiment.experiment_buckets.map do |bucket|
        {
          bucket_name: bucket.bucket_name,
          percentage_distribution: bucket.percentage_distribution
        }
      end,
      experiment_termination: {
        termination_type: experiment.experiment_termination.termination_type,
        termination_value: experiment.experiment_termination.termination_value
      },
      experiment_sampling_criteria: experiment.experiment_sampling_criteria.map do |criteria|
        {
          sampling_model: criteria.sampling_model,
          sampling_attribute: criteria.sampling_attribute,
          experiment_sampling_conditions: criteria.experiment_sampling_conditions.map do |condition|
            {
              model: condition.model,
              property: condition.property,
              value: condition.value,
              condition: condition.condition
            }
          end
        }
      end
    }
  end

  def validate_create_params
    permitted_params = params.permit(
      :name, :service_id, :active, :scheduled_start_date,
      :experiment_buckets => [
        :bucket_name,
        :percentage_distribution
      ],
      :experiment_termination => [
        :termination_type,
        :termination_value
      ],
      :experiment_sampling_criteria => [
        :sampling_model,
        :sampling_attribute,
        :experiment_sampling_conditions => [
          :model,
          :property,
          :value,
          :value_type,
          :condition
        ]
      ],
    )

    # Add default values for optional parameters
    permitted_params[:experiment_sampling_criteria] ||= []

    permitted_params[:experiment_sampling_criteria].map do |criteria|
      criteria[:experiment_sampling_conditions] ||= []
    end

    validation = RequestValidators::RequestValidatorService.new(
      @@creation_request_schema, permitted_params.to_hash
    ).validate_schema

    if !validation.success?
      return validation
    end

    # Manually validate the schema for experiment_termination
    # TODO Fix this
    termination_type = params[:experiment_termination][:termination_type]
    termination_value = params[:experiment_termination][:termination_value]

    if termination_type == 'SampleCount' && !(termination_value.is_a? Integer and termination_value > 0)
      return RequestValidators::RequestValidatorResponse.error(
        :invalid_schema,
        ['The provided request did not the required schema'],
        details: {
          :missing => [],
          :mismatches => [
            {
              :name => 'termination_value',
              :actual => termination_value.class.name.downcase,
              :expected => 'integer',
              :path => '/'
            }
          ]
        }
      )
    end

    if termination_type == 'DateTime'
      begin
        DateTime.parse(termination_value)
      rescue ArgumentError
        return RequestValidators::RequestValidatorResponse.error(
          :invalid_schema,
          ['The provided request did not match the required schema'],
          details: {
            :missing => [],
            :mismatches => [
              {
                :name => 'termination_value',
                :actual => termination_value.class.name.downcase,
                :expected => 'dateime',
                :path => '/'
              }
            ]
          }
        )
      end
    end

    validation
  end
end
