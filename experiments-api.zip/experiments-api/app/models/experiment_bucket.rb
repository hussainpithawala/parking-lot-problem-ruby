class ExperimentBucket < ApplicationRecord
  belongs_to :experiment
end
