class Experiment < ApplicationRecord
  belongs_to :service
  has_many :experiment_buckets
  has_one :experiment_termination
  has_many :experiment_sampling_criteria
  has_many :bucketed_samples

  def activate!
    self.active = true
    save!
  end

  def deactivate!
    self.active = false
    save!
  end
end
