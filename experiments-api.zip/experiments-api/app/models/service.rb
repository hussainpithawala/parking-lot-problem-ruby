class Service < ApplicationRecord
  has_many :experiments

  def activate!
    self.active = true
    save!
  end

  def deactivate!
    self.active = false
    save!
  end
end
