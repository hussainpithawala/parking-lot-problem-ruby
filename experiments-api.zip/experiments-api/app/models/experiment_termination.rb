class ExperimentTermination < ApplicationRecord
  belongs_to :experiment
end
