class ExperimentSamplingCriterium < ApplicationRecord
  belongs_to :experiment
  has_many :experiment_sampling_conditions
end
