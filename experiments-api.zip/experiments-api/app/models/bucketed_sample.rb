class BucketedSample < ApplicationRecord
  belongs_to :experiment

  def complete!
    self.complete = true
    self.completed_at = DateTime.now
    save!
  end
end
