class ExperimentSamplingCondition < ApplicationRecord
  belongs_to :experiment_sampling_criterium
end
