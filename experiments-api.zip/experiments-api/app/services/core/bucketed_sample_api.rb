module Core
  class BucketedSampleApi
    def create(params)
      experiment_api = Core::ExperimentApi.new

      response = experiment_api.get(params[:service_id], params[:experiment_id])

      if !response.success?
        SampleBucketingFailedEvent.new(params, response.error_code).trigger!
        return BucketedSampleResponse.wrap_error(response)
      end

      if !response.experiment.active
        SampleBucketingFailedEvent.new(params, :experiment_inactive).trigger!
        return BucketedSampleResponse.error(
          :experiment_inactive,
          ['Cannot bucket data for an inactive experiment']
        )
      end

      experiment = response.experiment

      if experiment_api.terminate? response.experiment
        experiment_api.deactivate(params[:service_id], params[:experiment_id])

        SampleBucketingFailedEvent.new(params, :experiment_terminated).trigger!
        return BucketedSampleResponse.error(
          :experiment_terminated,
          ['The experiment has reached its termination condition']
        )
      end

      bucketed_sample = BucketedSample.find_by(
        experiment_id: params[:experiment_id],
        sampled_entity: params[:sampled_entity],
        sampled_value: params[:sampled_value]
      )

      if bucketed_sample.nil?
        allocated_bucket = allocate_bucket(
          experiment.experiment_buckets,
          {
            experiment_id: params[:experiment_id],
            sampled_entity: params[:sampled_entity],
            sampled_value: params[:sampled_value]
          }
        )

        bucketed_sample = BucketedSample.create!(
          experiment_id: experiment.id,
          sampled_entity: params[:sampled_entity],
          sampled_value: params[:sampled_value],
          allocated_bucket: allocated_bucket,
          complete: params[:complete] || false,
          completed_at: (DateTime.now if params[:complete])
        )

        SampleBucketedEvent.new(bucketed_sample).trigger!
        BucketedSampleResponse.success(bucketed_sample, is_new: true)
      else
        BucketedSampleResponse.success(bucketed_sample, is_new: false)
      end
    end

    def get(service_id, experiment_id, bucketed_sample_id)
      response = Core::ExperimentApi.new.get(service_id, experiment_id)

      if !response.success?
        return BucketedSampleResponse.wrap_error(response)
      end

      bucketed_sample = BucketedSample.find_by(
        id: bucketed_sample_id, experiment_id: experiment_id
      )

      if bucketed_sample.nil?
        BucketedSampleResponse.error(
          :bucketed_sample_not_found, ["No bucketed sample found with the given id"]
        )

      else
        BucketedSampleResponse.success(bucketed_sample)

      end
    end

    def list(service_id, experiment_id)
      response = Core::ExperimentApi.new.get(service_id, experiment_id)

      if !response.success?
        return BucketedSampleResponse.wrap_error(response)
      end

      BucketedSamplesResponse.success(
        BucketedSample.where(experiment_id: experiment_id)
      )
    end

    def complete(service_id, experiment_id, bucketed_sample_id)
      response = Core::ExperimentApi.new.get(service_id, experiment_id)

      if !response.success?
        return BucketedSampleResponse.wrap_error(response)
      end

      bucketed_sample = BucketedSample.find_by(
        id: bucketed_sample_id, experiment_id: experiment_id
      )

      if bucketed_sample.nil?
        return BucketedSampleResponse.error(
          :bucketed_not_found, ['No bucketed sample found with the given id']
        )
      end

      if response.experiment.active
        bucketed_sample.complete!

        SampleMarkedCompleteEvent.new(bucketed_sample).trigger!
        BucketedSampleResponse.success(bucketed_sample)

      else
        SampleMarkCompletionFailedEvent.new(bucketed_sample, :experiment_terminated).trigger!
        BucketedSampleResponse.error(
          :experiment_terminated, ['Cannot mark a sample belonging to terminated experiment as complete']
        )

      end
    end

    private

    def allocate_bucket(buckets, sample)
      slots = buckets.sort_by { |bucket| bucket[:bucket_name] }
                     .inject([]) do |slot, bucket|
        threshold = slot.empty? ? 0 : slot.last[:end]
        slot + [{ name: bucket[:bucket_name], end: threshold + bucket[:percentage_distribution] }]
      end

      key = "#{sample[:experiment_id]}:#{sample[:sampled_entity]}:#{sample[:sampled_value]}"
      # Convert the key to a number between 0 to 100
      point = (XXhash.xxh32(key, BUCKET_HASH_SEED) / 4294967296.0) * 100

      # Locate the position of the point the slot
      slots.reject { |slot| slot[:end] < point }.first[:name]
    end
  end

  class BucketedSampleResponse < Response
    attr_reader :bucketed_sample, :is_new

    def initialize(bucketed_sample: nil, is_new: false, errors: nil, error_code: nil, error_details: nil)
      @bucketed_sample = bucketed_sample
      @is_new = is_new

      super(error_code: error_code, errors: errors, error_details: error_details)
    end

    def self.success(bucketed_sample, is_new: false)
      self.new(bucketed_sample: bucketed_sample, is_new: is_new)
    end
  end

  class BucketedSamplesResponse < Response
    attr_reader :bucketed_samples

    def initialize(bucketed_samples: nil, errors: nil, error_code: nil, error_details: nil)
      @bucketed_samples = bucketed_samples
      super(error_code: error_code, errors: errors, error_details: error_details)
    end

    def self.success(bucketed_samples)
      self.new(bucketed_samples: bucketed_samples)
    end
  end
end
