module Core
  class ExperimentApi
    def create(params)
      response = Core::ServiceApi.new.get(params[:service_id])

      if !response.success?
        ExperimentCreationFailedEvent.new(params, response.error_code).trigger!
        return ExperimentResponse.wrap_error(response)
      end

      service = response.service

      if !service.active
        ExperimentCreationFailedEvent.new(params, :service_inactive).trigger!

        return ExperimentResponse.error(
          :service_inactive,
          ['Cannot create experiment for an inactive service']
        )
      end

      # Convert the date fields in the parameters to the configured timezone
      params[:scheduled_start_date] = ActiveSupport::TimeZone[TIME_ZONE]
                                        .parse(params[:scheduled_start_date])
                                        .in_time_zone('UTC')

      if params[:experiment_termination][:termination_type] == 'DateTime'
        params[:experiment_termination][:termination_value] = ActiveSupport::TimeZone[TIME_ZONE].parse(
          params[:experiment_termination][:termination_value]
        ).in_time_zone('UTC')
      end

      begin
        ActiveRecord::Base.transaction do
          experiment = Experiment.create!(
            name: params[:name],
            service_id: params[:service_id],
            active: false,
            scheduled_start_date: params[:scheduled_start_date]
          )

          params[:experiment_buckets].each do |bucket|
            ExperimentBucket.create!(
              experiment_id: experiment.id,
              bucket_name: bucket[:bucket_name],
              percentage_distribution: bucket[:percentage_distribution]
            )
          end

          ExperimentTermination.create!(
            experiment_id: experiment.id,
            termination_type: params[:experiment_termination][:termination_type],
            termination_value: params[:experiment_termination][:termination_value]
          )

          params[:experiment_sampling_criteria].each do |criteria|
            experiment_sampling_criteria = ExperimentSamplingCriterium.create!(
              experiment_id: experiment.id,
              sampling_model: criteria[:sampling_model],
              sampling_attribute: criteria[:sampling_attribute]
            )

            criteria[:experiment_sampling_conditions].each do |condition|
              ExperimentSamplingCondition.create!(
                experiment_sampling_criterium_id: experiment_sampling_criteria.id,
                model: condition[:model],
                property: condition[:property],
                value: condition[:value],
                condition: condition[:condition],
              )
            end
          end

          ExperimentCreatedEvent.new(experiment).trigger!
          response = ExperimentResponse.success(experiment)
        end

      rescue ActiveRecord::RecordNotUnique

        ExperimentCreationFailedEvent.new(params, :duplicate_experiment_name).trigger!

        response = ExperimentResponse.error(
          :duplicate_experiment_name,
          ["An experiment with the provided name ('#{params[:name]}') already exists"]
        )
      end

      response
    end

    def get(service_id, experiment_id)
      response = Core::ServiceApi.new.get(service_id)

      if !response.success?
        return ExperimentResponse.wrap_error(response)
      end

      experiment = Experiment.find_by(
        id: experiment_id, service_id: service_id
      )

      if experiment.nil?
        ExperimentResponse.error(:experiment_not_found, ["No experiment found with the given id"])
      else
        ExperimentResponse.success(experiment)
      end
    end

    def list(service_id, active_only: true)
      response = Core::ServiceApi.new.get(service_id)

      if !response.success?
        return ExperimentResponse.wrap_error(response)
      end

      experiments = Experiment.where(service_id: service_id)

      if active_only
        experiments = experiments.where(active: true)
                                 .where(Experiment.arel_table[:scheduled_start_date].lt(DateTime.now))
      end

      ExperimentsResponse.success(experiments)
    end

    def activate(service_id, experiment_id)
      resp = get(service_id, experiment_id)

      if resp.success?
        # Ensure that the termination condition has not been met

        if terminate? resp.experiment
          return ExperimentResponse.error(
            :experiment_terminated,
            ['The experiment has reached its termination condition']
          )
        end

        resp.experiment.activate!
        ExperimentActivatedEvent.new(resp.experiment).trigger!
      end

      resp
    end

    def deactivate(service_id, experiment_id)
      resp = get(service_id, experiment_id)

      if resp.success?
        resp.experiment.deactivate!
        ExperimentDeactivatedEvent.new(resp.experiment).trigger!
      end

      resp
    end

    def terminate?(experiment)
      termination_type = experiment.experiment_termination.termination_type

      if termination_type == 'SampleCount'
        terminate_by_sample_count?(experiment)
      else
        terminate_by_date?(experiment)
      end
    end

    def terminate_by_sample_count?(experiment)
      desired_samples = experiment.experiment_termination.termination_value.to_i
      actual_samples = experiment.bucketed_samples.count(:id).to_f

      if actual_samples >= desired_samples
        desired_distribution = Hash[
          experiment.experiment_buckets
                    .select(:bucket_name, :percentage_distribution)
                    .map { |bucket| [bucket.bucket_name, bucket.percentage_distribution] }
        ]

        actual_distribution = Hash[
          experiment.bucketed_samples
                    .where(complete: true)
                    .group(:allocated_bucket)
                    .count(:id)
                    .map { |bucket, count| [bucket, (count / actual_samples) * 100] }
        ]

        desired_distribution.keys.all? do |bucket|
          (desired_distribution.fetch(bucket, 0) - actual_distribution.fetch(bucket, 0)).abs <= 5
        end
      end
    end

    def terminate_by_date?(experiment)
      termination_date = experiment.experiment_termination.termination_value
      DateTime.parse(termination_date) < DateTime.now
    end
  end

  class ExperimentResponse < Response
    attr_reader :experiment

    def initialize(experiment: nil, errors: nil, error_code: nil, error_details: nil)
      @experiment = experiment

      super(error_code: error_code, errors: errors, error_details: error_details)
    end

    def self.success(experiment)
      self.new(experiment: experiment)
    end
  end

  class ExperimentsResponse < Response
    attr_reader :experiments

    def initialize(experiments: nil, errors: nil, error_code: nil, error_details: nil)
      @experiments = experiments
      super(error_code: error_code, errors: errors, error_details: error_details)
    end

    def self.success(experiments)
      self.new(experiments: experiments)
    end
  end
end
