module Core
  class Response
    attr_reader :errors, :error_code, :error_details

    def initialize(errors: nil, error_code: nil, error_details: nil)
      @errors = errors
      @error_code = error_code
      @error_details = error_details
    end

    def self.error(code, errors, details: nil)
      self.new(error_code: code, errors: errors, error_details: details)
    end

    def self.wrap_error(response)
      self.new(
        error_code: response.error_code,
        errors: response.errors,
        error_details: response.error_details
      )
    end

    def success?
      !(errors && errors.any?)
    end
  end
end
