module Core
  class ServiceApi
    def create(name, active: true)
      begin
        service = Service.create!(name: name, active: active)

        ServiceCreatedEvent.new(service).trigger!
        ServiceResponse.success(service)

      rescue ActiveRecord::RecordNotUnique

        ServiceCreationFailedEvent.new(
          { name: name, active: active }, :duplicate_service_name
        ).trigger!

        ServiceResponse.error(
          :duplicate_service_name,
          ["A service with the provided name ('#{name}') already exists"]
        )

      end
    end

    def list
      ServiceResponse.success(Service.all)
    end

    def get(service_id)
      begin
        ServiceResponse.success(Service.find(service_id))

      rescue ActiveRecord::RecordNotFound
        ServiceResponse.error(
          :service_not_found,
          ["No service found with the given id"]
        )
      end
    end

    def activate(service_id)
      resp = get(service_id)

      if resp.success?
        resp.service.activate!
        ServiceActivatedEvent.new(resp.service).trigger!
      end

      resp
    end

    def deactivate(service_id)
      resp = get(service_id)

      if resp.success?
        resp.service.deactivate!
        ServiceDeactivatedEvent.new(resp.service).trigger!
      end

      resp
    end
  end

  class ServiceResponse < Response
    attr_reader :service

    def initialize(service: nil, errors: nil, error_code: nil, error_details: nil)
      @service = service
      super(error_code: error_code, errors: errors, error_details: error_details)
    end

    def self.success(service)
      self.new(service: service)
    end
  end
end
