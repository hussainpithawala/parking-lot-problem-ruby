class ErrorsService
  class Base < StandardError
    attr_reader :message, :details

    def initialize(message, details: {})
      @message = message
      @details = details
    end

    def status_code
      :internal_server_error
    end
  end

  class InternalError < Base
    def initialize()
      super('Internal server error')
    end
  end

  class MissingParameterError < Base
    def status_code
      :bad_request
    end
  end

  class InvalidSchemaError < Base
    def status_code
      :bad_request
    end
  end

  class InvalidAccessError < Base
    def status_code
      :unauthorized
    end
  end

  class NotFoundError < Base
    def status_code
      :not_found
    end
  end

  class InactiveEntityError < Base
    def status_code
      :precondition_failed
    end
  end

  class DuplicateValueError < Base
    def self.from(exception, message: 'Duplicate values encountered')
      unless exception.is_a? ActiveRecord::RecordNotUnique
        return InternalError.new
      end

      # The exception does not provide structured access to the offending field
      # but the underlying pg exception has the field name, extract it from there
      duplicate_fields = exception.message
        .split("\n")
        .second
        .match(/DETAIL:[\s]+Key \(([^=]+)\)=.*/)
        .captures[0]
        .split(', ')
        .map { |name| name.intern }

      return self.new(message: message, details: {duplicate_fields: duplicate_fields})
    end

    def status_code
      :bad_request
    end
  end

  class ServiceIdMissingError < MissingParameterError
  end

  class ServiceNotFoundError < NotFoundError
  end

  class ServiceInactiveError < InactiveEntityError
  end

  class DuplicateServiceNameError < DuplicateValueError
  end

  class ExperimentNotFoundError < NotFoundError
  end

  class ExperimentInactiveError < InactiveEntityError
  end

  class DuplicateExperimentNameError < DuplicateValueError
  end

  class BucketedSampleNotFoundError < NotFoundError
  end
end
