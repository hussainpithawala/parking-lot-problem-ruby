module UtilService
  def self.json_safe_parse(json_string)
    begin
      json_string.blank? ? {} : JSON.parse(json_string)
    rescue JSON::ParserError => e
      Rails.logger.error({error: e.message, backtrace: e.backtrace})
      {}
    end
  end

  def self.local_date
    DateTime.now.in_time_zone(TIME_ZONE).to_date
  end

  def self.local_time_now
    DateTime.now.in_time_zone(TIME_ZONE)
  end
end