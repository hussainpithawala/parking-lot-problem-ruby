module RequestValidators
  class RequestValidatorService
    attr_accessor :validations, :params, :required_attributes, :request_params

    @@type_mismatch_re = /The property '#(?<path>.*)\/(?<field>.+)' of type (?<actual>\w+) did not match the following type: (?<expected>\w+).*/
    @@field_missing_re = /The property '#(?<path>[^']+)' did not contain a required property of '(?<field>\w+)'.*/

    def initialize(validations, params)
      @validations = validations
      @params = params
      @request_params = params.keys
      @required_attributes = validations['required'].map(&:to_s)
    end

    def validate_schema
      errors = JSON::Validator.fully_validate(validations, params)

      if errors.empty?
        RequestValidatorResponse.success(params.deep_symbolize_keys)

      else
        missing_fields = errors.map { |error| error.match @@field_missing_re }
          .reject { |match| match.nil? }
          .map do |match|
            {:name => match[:field], :path => match[:path]}
          end

        mismatched_fields = errors.map { |error| error.match @@type_mismatch_re }
          .reject { |match| match.nil? }
          .map do |match|
            {
              :name => match[:field],
              :actual => match[:actual],
              :expected => match[:expected],
              :path => match[:path]
            }
          end

        RequestValidatorResponse.error(
          :invalid_schema,
          ['The provided request did not match the required schema'],
          details: {
            :missing => missing_fields,
            :mismatches => mismatched_fields
          }
        )
      end
    end
  end

  class RequestValidatorResponse
    attr_reader :errors, :error_code, :parameters, :error_details

    def initialize(parameters: nil, errors: nil, error_code: nil, error_details: nil)
      @parameters = parameters

      @errors = errors
      @error_code = error_code
      @error_details = error_details
    end

    def self.error(code, errors, details: nil)
      self.new(error_code: code, errors: errors, error_details: details)
    end

    def self.success(parameters)
      self.new(parameters: parameters)
    end

    def success?
      !(errors && errors.any?)
    end
  end
end
