#!/usr/bin/env bash

cd $APP_HOME

bundle exec sidekiq -C config/sidekiq.yml -e $RAILS_ENV