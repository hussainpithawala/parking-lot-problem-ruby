# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.0].define(version: 2019_06_06_104714) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "pgcrypto"
  enable_extension "plpgsql"

  create_table "bucketed_samples", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.uuid "experiment_id", null: false
    t.string "sampled_value"
    t.string "sampled_entity"
    t.string "allocated_bucket"
    t.boolean "complete"
    t.datetime "completed_at", precision: nil
    t.datetime "created_at", precision: nil, null: false
    t.datetime "updated_at", precision: nil, null: false
    t.index ["experiment_id", "sampled_entity", "sampled_value"], name: "index_experiment_sampled_entity_value", unique: true
    t.index ["experiment_id"], name: "index_bucketed_samples_on_experiment_id"
  end

  create_table "experiment_buckets", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.uuid "experiment_id"
    t.string "bucket_name"
    t.integer "percentage_distribution"
    t.datetime "created_at", precision: nil, null: false
    t.datetime "updated_at", precision: nil, null: false
    t.index ["experiment_id", "bucket_name"], name: "index_experiment_buckets_on_experiment_id_and_bucket_name", unique: true
    t.index ["experiment_id"], name: "index_experiment_buckets_on_experiment_id"
  end

  create_table "experiment_sampling_conditions", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.uuid "experiment_sampling_criterium_id", null: false
    t.string "model"
    t.string "property"
    t.string "value"
    t.string "condition"
    t.datetime "created_at", precision: nil, null: false
    t.datetime "updated_at", precision: nil, null: false
    t.index ["experiment_sampling_criterium_id"], name: "fk_experiment_sampling_criteria"
  end

  create_table "experiment_sampling_criteria", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.uuid "experiment_id", null: false
    t.string "sampling_model"
    t.string "sampling_attribute"
    t.datetime "created_at", precision: nil, null: false
    t.datetime "updated_at", precision: nil, null: false
    t.index ["experiment_id"], name: "index_experiment_sampling_criteria_on_experiment_id"
  end

  create_table "experiment_terminations", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.uuid "experiment_id", null: false
    t.string "termination_type"
    t.string "termination_value"
    t.datetime "created_at", precision: nil, null: false
    t.datetime "updated_at", precision: nil, null: false
    t.index ["experiment_id"], name: "index_experiment_terminations_on_experiment_id"
  end

  create_table "experiments", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.string "name"
    t.boolean "active", default: true
    t.uuid "service_id", null: false
    t.datetime "last_deactivated_at", precision: nil
    t.datetime "last_activated_at", precision: nil
    t.datetime "scheduled_start_date", precision: nil
    t.datetime "created_at", precision: nil, null: false
    t.datetime "updated_at", precision: nil, null: false
    t.index ["name", "service_id"], name: "index_experiments_on_name_and_service_id", unique: true
    t.index ["service_id"], name: "index_experiments_on_service_id"
  end

  create_table "services", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.string "name"
    t.boolean "active", default: true
    t.datetime "created_at", precision: nil, null: false
    t.datetime "updated_at", precision: nil, null: false
    t.index ["name"], name: "index_services_on_name", unique: true
  end

  add_foreign_key "bucketed_samples", "experiments", on_delete: :cascade
  add_foreign_key "experiment_buckets", "experiments", on_delete: :cascade
  add_foreign_key "experiment_sampling_conditions", "experiment_sampling_criteria", name: "fk_experiment_sampling_criteria", on_delete: :cascade
  add_foreign_key "experiment_sampling_criteria", "experiments", on_delete: :cascade
  add_foreign_key "experiment_terminations", "experiments", on_delete: :cascade
  add_foreign_key "experiments", "services", on_delete: :cascade
end
