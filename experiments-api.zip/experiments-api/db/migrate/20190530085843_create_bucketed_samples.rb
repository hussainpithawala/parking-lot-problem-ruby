class CreateBucketedSamples < ActiveRecord::Migration[5.2]
  def change
    create_table :bucketed_samples, id: :uuid do |t|
      t.references :experiment, foreign_key: true, type: :uuid, null: false
      t.string :sampled_value
      t.string :sampled_entity
      t.string :allocated_bucket
      t.boolean :complete
      t.datetime :completed_at

      t.timestamps
    end
  end
end
