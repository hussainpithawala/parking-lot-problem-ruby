class CreateExperimentBuckets < ActiveRecord::Migration[5.2]
  def change
    create_table :experiment_buckets, id: :uuid do |t|
      t.references :experiment, foreign_key: true, type: :uuid
      t.string :bucket_name
      t.integer :percentage_distribution

      t.timestamps
    end

    add_index :experiment_buckets, [:experiment_id, :bucket_name], :unique => true
  end
end
