class RemoveScheduledEndDate < ActiveRecord::Migration[5.2]
  def change
    remove_column :experiments, :scheduled_end_date
  end
end
