class RenameAttributeColumn < ActiveRecord::Migration[5.2]
  def change
    rename_column :experiment_sampling_conditions, :attribute, :property
  end
end
