class CreateExperimentSamplingCriteria < ActiveRecord::Migration[5.2]
  def change
    create_table :experiment_sampling_criteria, id: :uuid do |t|
      t.references :experiment, foreign_key: true, type: :uuid, null: false
      t.string :sampling_model
      t.string :sampling_attribute

      t.timestamps
    end
  end
end
