class CreateExperimentSamplingConditions < ActiveRecord::Migration[5.2]
  def change
    create_table :experiment_sampling_conditions, id: :uuid do |t|
      t.references :experiment_sampling_criteria, foreign_key: true, type: :uuid, null: false, index: { name: :fk_experiment_sampling_criteria }
      t.string :model
      t.string :attribute
      t.string :value
      t.string :condition

      t.timestamps
    end
  end
end
