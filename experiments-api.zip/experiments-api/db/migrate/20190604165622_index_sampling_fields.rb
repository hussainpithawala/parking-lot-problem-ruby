class IndexSamplingFields < ActiveRecord::Migration[5.2]
  def change
    add_index :bucketed_samples, [:experiment_id, :sampled_entity, :sampled_value], :unique => true, :name => 'index_experiment_sampled_entity_value'
  end
end
