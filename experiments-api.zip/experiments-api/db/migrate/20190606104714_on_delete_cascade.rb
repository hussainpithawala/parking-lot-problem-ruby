class OnDeleteCascade < ActiveRecord::Migration[5.2]
  def change
    remove_foreign_key :experiments, :services
    add_foreign_key :experiments, :services, on_delete: :cascade

    remove_foreign_key :experiment_terminations, :experiments
    add_foreign_key :experiment_terminations, :experiments, on_delete: :cascade

    remove_foreign_key :experiment_buckets, :experiments
    add_foreign_key :experiment_buckets, :experiments, on_delete: :cascade

    remove_foreign_key :experiment_sampling_criteria, :experiments
    add_foreign_key :experiment_sampling_criteria, :experiments, on_delete: :cascade

    remove_foreign_key :experiment_sampling_conditions, :experiment_sampling_criteria
    add_foreign_key :experiment_sampling_conditions, :experiment_sampling_criteria, on_delete: :cascade, name: :fk_experiment_sampling_criteria

    remove_foreign_key :bucketed_samples, :experiments
    add_foreign_key :bucketed_samples, :experiments, on_delete: :cascade
  end
end
