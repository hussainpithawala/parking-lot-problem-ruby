class CreateExperimentTerminations < ActiveRecord::Migration[5.2]
  def change
    create_table :experiment_terminations, id: :uuid do |t|
      t.references :experiment, foreign_key: true, type: :uuid, null: false
      t.string :termination_type
      t.string :termination_value

      t.timestamps
    end
  end
end
