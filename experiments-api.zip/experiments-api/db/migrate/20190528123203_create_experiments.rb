class CreateExperiments < ActiveRecord::Migration[5.2]
  def change
    create_table :experiments, id: :uuid do |t|
      t.string :name
      t.boolean :active, default: true
      t.references :service, foreign_key: true, type: :uuid, null: false
      t.datetime :last_deactivated_at
      t.datetime :last_activated_at
      t.datetime :scheduled_start_date
      t.datetime :scheduled_end_date

      t.timestamps
    end

    add_index :experiments, [:name, :service_id], :unique => true
  end
end
