class RenameExperimentCriteriaIdColumn < ActiveRecord::Migration[5.2]
  def change
    rename_column :experiment_sampling_conditions, :experiment_sampling_criteria_id, :experiment_sampling_criterium_id
  end
end
