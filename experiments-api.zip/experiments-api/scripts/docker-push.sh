#!/usr/bin/env bash

echo "${DOCKERHUB_PASSWORD}" | docker login -u "${DOCKERHUB_USERNAME}" --password-stdin

docker build -t tscreditline/experiments-api:"${TRAVIS_BRANCH}-${TRAVIS_COMMIT}" .
docker push tscreditline/experiments-api:"${TRAVIS_BRANCH}-${TRAVIS_COMMIT}"

docker tag tscreditline/experiments-api:"${TRAVIS_BRANCH}-${TRAVIS_COMMIT}" tscreditline/experiments-api:latest
docker push tscreditline/experiments-api:latest