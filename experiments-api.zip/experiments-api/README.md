# README

This README would normally document whatever steps are necessary to get the
application up and running.

* Ruby version
    ruby-2.5.1
    
    postgresql-10
    
    redis 4 
    
* System dependencies and setup
    
    1. To install dependencies use rvm to create a gemset
    ```
       $ rvm gemset create experiments
       $ rvm --rvmrc --create ruby-3.0.0@experiments       
    ```
    
    2. We've now created an isolated environment to install our dependencies. Let's 
       install our dependency manager
    
    ```
        $ gem install bundler
    ```
    
    3. Install dependencies
    
    ```
        $ bundle install
    ```

    4. Create databases. This creates our development and test databases
    
    ```
        $ cp config/database.yml.sample config/database.yml
        $ rake db:create RAILS_ENV=development
        $ rake db:create RAILS_ENV=test
    ```
    
    5. Migrate databases
    
    ```
        $ rake db:migrate 
        $ rake db:test:prepare OR rake db:migrate RAILS_ENV=test
    ```
    
    6. Ensure redis is running
    7. Install direnv and create .envrc file in the application root to install development env specific configurations
           Follow directions here https://direnv.net/
        ```
        # local configs
        export EXCON_DEBUG=false
        
        # env configs
        export DB_URL=postgres://experiments_user@localhost/experiments_api_development
        #export DB_URL=postgres://experiments_user@localhost/experiments_api_test
        export REDIS_URL=redis://localhost:6379/0
        
        export SIDEKIQ_USERNAME="root"
        export SIDEKIQ_PASSWORD="admin"
        
        export RAISE_DEVELOPMENT_ERRORS=true
        
        export EVENT_PUBLISHER_URL=http://localhost:3000/events
        #export EVENT_PUBLISHER_URL="http://172.16.13.253:34016/events"
        
        export RAILS_ENV=development
        export COUNTRY=indonesia
          ```

    8. Run tests to verify everything is working
    ```
        $ rspec spec/
    ```

