Rails.application.routes.draw do
  mount Rswag::Api::Engine => '/api-docs'
  mount Rswag::Ui::Engine => '/api-docs'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  namespace :api do
    namespace :v1 do
      resource :services, only: [] do
        post '/' => 'services#create'
        get '/' => 'services#list'
      end

      resources :services, only: [] do
        get '/' => 'services#get'
        put '/activate' => 'services#activate'
        put '/deactivate' => 'services#deactivate'
      end

      resource :experiments, only: [] do
        get '/' => 'experiments#list'
        post '/' => 'experiments#create'
      end

      resources :experiments, only: [] do
        get '/' => 'experiments#get'
        put '/activate' => 'experiments#activate'
        put '/deactivate' => 'experiments#deactivate'

        resource :bucketed_samples, only: [] do
          get '/' => 'bucketed_samples#list'
          post '/' => 'bucketed_samples#create'
        end

        resources :bucketed_samples, only: [] do
          get '/' => 'bucketed_samples#get'
          put '/complete' => 'bucketed_samples#complete'
        end

      end
    end
  end

  get '/check' => 'welcome#check'
  root 'welcome#index'
  require 'sidekiq/web'
  require 'sidekiq-scheduler/web'
  Sidekiq::Web.use Rack::Auth::Basic do |username, password|
    username == ENV["SIDEKIQ_USERNAME"] && password == ENV["SIDEKIQ_PASSWORD"]
  end if Rails.env.production? or Rails.env.staging? or Rails.env.sandbox?

  mount Sidekiq::Web => '/sidekiq'
end
