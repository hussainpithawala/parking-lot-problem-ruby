ExperimentsApi::Application.configure do

  config.lograge.formatter = Class.new do |fmt|
    def fmt.call(data)
      {
          method: data[:method],
          path: data[:path],
          params: data[:params],
          request_id: data[:request_id],
          response: data[:response],
          db: data[:db],
          status: data[:status],
          controller: data[:controller],
          duration: data[:duration],
          view: data[:view],
          real_ip: data[:real_ip]
      }
    end
  end

  config.lograge.enabled = true
  config.log_level = :info
  config.lograge_formatter = Lograge::Formatters::Json.new
  config.lograge.custom_options = lambda do |event|
    {
        request_id: event.payload[:request_id],
        real_ip: event.payload[:real_ip],
        params: event.payload[:params],
        response: UtilService.json_safe_parse(event.payload[:response])
    }
  end
end

