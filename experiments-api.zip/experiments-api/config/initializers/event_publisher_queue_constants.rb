EVENT_PUBLISHER_QUEUES_IDS = ['67ce52a1-4f28-4634-8437-b188cd5eda66',
                              'e1166979-53d5-4193-a214-d7f944555536',
                              'bf316a57-a877-41cb-8bf7-389c0ab0c5d2',
                              '0573d06f-4aca-4600-b49d-eb715365ed14',
                              'fea71e29-7c75-4d3e-80f3-346ea8ae1e30',
                              '20fb96c8-e4c4-4d9b-90ba-155481c6c78d',
                              'b1d2a320-23c6-4c2e-97d5-ffd8740f1f2c',
                              '873b1a0f-ba5e-40ae-8fb8-d82fc0a8bfc9',
                              'd1b6b184-a797-46e8-9360-fe6a27d5a013',
                              'cc5c4fa4-a2eb-4d15-a222-3249e62d0425',
                              '44b22698-1676-4216-bc9a-3b1da6071b89',
                              '60af94a2-ad69-4c5d-b1cb-90127e21f6b5']

queue_ids_to_integers = {}

EVENT_PUBLISHER_QUEUES_IDS.each do |queue_id|
  queue_ids_to_integers[queue_id] = Integer("0x#{Digest::SHA1.hexdigest(queue_id)}")
end

QUEUE_INTEGER_TO_IDS = queue_ids_to_integers.invert
EVENT_PUBLISHER_QUEUE_CONTINUUM = QUEUE_INTEGER_TO_IDS.keys.sort