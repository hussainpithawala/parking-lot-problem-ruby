def initialize_sidekiq_connection
  Sidekiq.configure_server do |config|
    config.redis = { url: ENV['REDIS_URL'],
                     network_timeout: 5,
                     # namespace: "redis-#{Rails.env}"
    }
    if not Rails.env.development?
      config.error_handlers << Proc.new { |ex,ctx_hash| experimentscapture_exception("sidekick Error: #{ex.message}. #{ctx_hash.as_json}") }
    end
  end

  Sidekiq.configure_client do |config|
    config.redis = {
        url: ENV['REDIS_URL'],
        network_timeout: 5,
        # namespace: "redis-#{Rails.env}"
    }
  end

  # Sidekiq.redis do |c|
  #   Rails.logger.info("Sidekiq Redis ping: #{c.redis.ping}")
  # end if ENV['ASSET_PRECOMPILE'].blank?
end

def reconnect_sidekiq
  Sidekiq.redis_pool.shutdown{|c| nil }
  initialize_sidekiq_connection
end

initialize_sidekiq_connection
# Sidekiq::Logging.logger = Rails.logger
Rails.logger = Sidekiq.logger
ActiveRecord::Base.logger = Sidekiq.logger

Sidekiq.logger.level = ENV['SIDEKIQ_LOGGER_LEVEL'] || Logger::DEBUG
Rails.logger.info({message: "Sidekiq connection initialize. Done!"})