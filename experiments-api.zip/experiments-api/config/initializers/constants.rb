# base constants

# env vars

COUNTRY=ENV['COUNTRY']

country_config=YAML.load_file('config/geo.settings.yml').fetch(COUNTRY)
CURRENCY=country_config.fetch('CURRENCY')
COUNTRY_CODE=country_config.fetch('COUNTRY_CODE')
TIME_ZONE=country_config.fetch('TIME_ZONE')
LOCALE=country_config.fetch('LOCALE')


required_env_vars = {
    "COUNTRY" => COUNTRY
}

if Rails.env.development?
  required_env_vars.each do |var|
    Rails.logger.debug("LOADED: #{var}")
    raise "Environment variable: #{var}, not present" if not var.present?
  end
end

RAISE_DEVELOPMENT_ERRORS = (ENV['RAISE_DEVELOPMENT_ERRORS'] || false).to_s
SYSTEM_EVENT_ID = 'bc29a46a-9433-4c69-9d2f-61df9ad997f7'

BUCKET_HASH_SEED = 1554089813
