def initialize_redis_connection
  if Rails.env.test?
    Redis.current = Redis.new(url: (ENV['REDIS_URL'] || 'redis://127.0.0.1:6379'), db: 15)
  elsif Rails.env.qa?
    Redis.current = Redis.new(url: (ENV['REDIS_URL'] || 'redis://127.0.0.1:6379'), db: 15)
  else
    Redis.current = Redis.new(url: (ENV['REDIS_URL'] || 'redis://127.0.0.1:6379'))
  end

  Rails.logger.info("Redis connection initialized.")
  Rails.logger.info("Redis.current.ping: #{Redis.current.ping}") if ENV['ASSET_PRECOMPILE'].blank?
end

def reconnect_redis
  Redis.current.disconnect
  initialize_redis_connection
end

initialize_redis_connection
Rails.logger.info({message: "Redis connection initialize. Done!"})

