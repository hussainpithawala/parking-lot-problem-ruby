defmodule Service.Endpoint do
  @moduledoc false

  use Plug.Router
  require Logger

  plug Service.Prometheus.PrometheusExporter
  plug Service.Prometheus.PipelineInstrumenter

  plug(:match)
  plug(:dispatch)


  get "/" do
    conn
    |> put_resp_content_type("text/plain")
    |> send_resp(200, "Try /svc/get_vendor/<service_name> to fetch the vendor")
  end

  forward("/ht", to: Service.HtRouter)
  forward("/svc", to: Service.Router)

  match _ do
    send_resp(conn, 404, "Oops! Don't know what to do")
  end

  def child_spec(opts) do
    %{
      id: __MODULE__,
      start: {__MODULE__, :start_link, [opts]}
    }
  end

  def start_link(_opts) do
    with {:ok, [port: port] = config} <- Application.fetch_env(:switch_over_service, __MODULE__) do
      Logger.info("Starting service at http://localhost:#{port}}")
      Plug.Adapters.Cowboy.http(__MODULE__, [], config)
    end
  end
end
