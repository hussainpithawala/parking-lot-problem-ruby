defmodule DAO.DB do
  require Logger
  @dynamodb Application.get_env(:switch_over_service, :dynamodb)

  def initialize_vendor(vendor) do
    list = [
      &DAO.DB.obtain_lock/1
    ]
    results = Spawn.Parallel.pmap_fx(list, vendor)
    if Enum.reduce(results, true, fn (x, acc) -> x && acc end) do
      Logger.info(
        "Starting vendor initialization after obtaining the lock and confirming that vendor: #{vendor[:code]}
        is not set as the current vendor for service: #{vendor[:service_name]}"
      )
      initialize_keys(vendor)
      true
    else
      Logger.info("Vendor Initialization is avoided in DB, please check the logs for more details")
      false
    end
  end

  def delete_lock(vendor) do
    Task.async(
      fn ->
        lock_duration = Application.get_env(:switch_over_service, :lock_duration)
        Process.sleep(lock_duration)
        is_deleted = @dynamodb.delete_item(vendor[:service_name], "initialize")
        Logger.info("Deleted key : #{is_deleted}")
      end
    )
  end

  def obtain_lock(vendor) do
    put_map = DAO.DBUtil.generate_lock_entry(vendor)
    is_lock_granted = @dynamodb.put_item_if_not_exists(put_map)
    Logger.info("Is lock enabled for #{vendor[:service_name]} : #{is_lock_granted}")
    is_lock_granted
  end

  def initialize_keys(vendor) do
    if !vendor[:primary] do
      initialize_keys_non_primary_vendor(vendor)
    else
      initialize_keys_primary_vendor(vendor)
    end
  end

  def initialize_keys_primary_vendor(vendorConfig) do
    vendorMap = %{service: vendorConfig[:service_name], vendor: vendorConfig[:code],
      primary: true, current: true,
      retry_count: vendorConfig[:retry],
      error_count: 0, error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0, epm_epoch: DAO.DBUtil.get_current_epoch(),
      success_count: 0, success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 0,ov_in_action: false}
    put_vendor(vendorMap)
  end

  def initialize_keys_non_primary_vendor(vendorConfig) do
    vendorMap = %{service: vendorConfig[:service_name], vendor: vendorConfig[:code],
      primary: false, current: true, retry_count: vendorConfig[:retry], error_count: 0, error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0, epm_epoch: DAO.DBUtil.get_current_epoch(), success_count: 0, success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 0,ov_in_action: false}
    put_vendor(vendorMap)
  end

  def get_vendor(service_name, vendor_code) do
    try do
      vendorDB = @dynamodb.get_item(service_name, vendor_code)
      vendor = DAO.DBUtil.generate_vendor_map_from_db_json(vendorDB)
    rescue
      e ->
        vendor_config = get_vendor_from_ets(service_name, vendor_code)
        initialize_vendor(vendor_config)
        vendorDB = @dynamodb.get_item(service_name, vendor_code)
        vendor = DAO.DBUtil.generate_vendor_map_from_db_json(vendorDB)
    end
  end

  def put_vendor(vendor) do
    if vendor[:current]==true do

      #Mark other vendors as false
      #Put item
      vendor_list = get_all_vendors_for_given_service(vendor[:service])
      other_vendors = Enum.filter(vendor_list, fn vendor_map -> vendor[:vendor]!=vendor_map[:vendor] end)

      Enum.map(other_vendors,
        fn vendor_map ->
          Logger.info("Inside other vendor: #{vendor_map[:vendor]}")
          vendor_map = %{vendor_map | current: false}
          put_vendor_core(vendor_map)
        end)
      put_vendor_core(vendor)
    else
      #Check if any other vendor is already true
      vendor_list = get_all_vendors_for_given_service(vendor[:service])
      other_vendors = Enum.filter(vendor_list, fn vendor_map ->
        Logger.info("Return value for #{vendor_map[:vendor]} :  #{vendor[:vendor]!=vendor_map[:vendor] && vendor_map[:current]==true}")
        vendor[:vendor]!=vendor_map[:vendor] && vendor_map[:current]==true end)
      case other_vendors do
        [] -> false
        _ -> put_vendor_core(vendor)
      end
    end
  end

  def put_vendor_core(vendor) do
    vendor_item = DAO.DBUtil.generate_dynamodb_json(vendor)
    is_put = @dynamodb.put_item(vendor_item)
    Logger.info("Is put successful : #{is_put}")
  end

  def get_all_vendors_for_given_service(service_name) do
    Logger.info("Get all vendors for Service #{service_name}")
    vendor_response_list = @dynamodb.list_items(service_name)
    case vendor_response_list do
      :undefined -> []
      _ ->  vendor_response_list = Enum.filter(vendor_response_list,
            fn vendor_dynamodb -> vendor_dynamodb["VENDOR"]["S"] != "initialize" end)
            vendor_list = Enum.map(vendor_response_list, fn vendor -> DAO.DBUtil.generate_vendor_map_from_db_json(vendor) end)
    end
  end

  def get_vendor_from_ets(service_name, vendor_code) do
    Logger.info("looking for #{service_name}-#{vendor_code}")
    # load vendor from ets
    [record | _] = :ets.lookup(:service_vendors, "#{service_name}-#{vendor_code}")
    elem(record, 1)
  end

  def scan_table() do
    scan_output = @dynamodb.scan_table()
    scan_output = Enum.filter(scan_output, fn vendor -> vendor["VENDOR"]["S"] != "initialize" end)
  end
end
