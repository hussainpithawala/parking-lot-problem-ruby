defmodule DAO.DAOImpl do
  @moduledoc false
  require Logger
  alias DAO.DB, as: DB
  alias DAO.Redis, as: Redis

  #TODO:- Rethink over this.
  def initialize_vendor(vendor) do
    is_locked= DB.initialize_vendor(vendor)
    redis_response = Redis.lock_and_initialize_vendor(vendor)
      case redis_response do
        :undefined -> update_keydb_entry(false)
        :nil ->
          verify_and_take_snapshot_from_DB_to_cache()
          DB.delete_lock(vendor)
        _ -> DB.delete_lock(vendor)
      end

  end

  def verify_and_take_snapshot_from_DB_to_cache() do
    is_keydb_running = get_keydb_entry()
    if !is_keydb_running do
        apply_snapshot()
        update_keydb_entry(true)
    end
  end


#  Apply snapshot from DynamoDB to keydb
  def apply_snapshot() do
    Logger.info("Taking Snapshot DB -> keyDB")
    vendor_response_list = DB.scan_table()
    vendor_list = Enum.map(vendor_response_list, fn vendor -> DAO.DBUtil.generate_vendor_map_from_db_json(vendor) end)
    Enum.map(vendor_list, fn vendor -> Redis.put_vendor(vendor) end)
  end

  def get_vendor(service_name, vendor_code) do
    redis_response = Redis.get_vendor(service_name, vendor_code)
    case redis_response do
      :undefined ->
        update_keydb_entry(false)
        DB.get_vendor(service_name, vendor_code)
      :nil ->
        verify_and_take_snapshot_from_DB_to_cache()
        DB.get_vendor(service_name, vendor_code)
      _  ->
        redis_response
    end
  end

  def put_vendor(vendor_map) do
    resp = Redis.put_vendor(vendor_map)
    Task.start(fn  ->
      Logger.info("Putting vendor in DB for #{vendor_map[:vendor]} -->  Current value : #{vendor_map[:current]}")
      DB.put_vendor(vendor_map) end)
    case resp do
      :undefined -> update_keydb_entry(false)
      :nil -> verify_and_take_snapshot_from_DB_to_cache()
      _ -> Logger.info("Successfully put vendor")
    end
  end

  def get_all_vendors_for_provided_service(service_name) do
    redis_response = Redis.get_all_vendors(service_name)
    case redis_response do
      :undefined ->
        update_keydb_entry(false)
        DB.get_all_vendors_for_given_service(service_name)
      :nil ->
        verify_and_take_snapshot_from_DB_to_cache()
        DB.get_all_vendors_for_given_service(service_name)
      _ ->
        redis_response
    end
  end

  defp update_keydb_entry(is_keydb_running) do
    :ets.insert(
      :service_vendors,
      {"is_keydb_running", is_keydb_running}
    )
  end

  defp get_keydb_entry() do
    [record | _] = :ets.lookup(:service_vendors, "is_keydb_running")
    elem(record, 1)
  end

end


