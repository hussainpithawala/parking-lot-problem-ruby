defmodule DAO.DBUtil do

  require Logger

  def is_window_expired(created_epoch, time_interval) do
    Logger.info("is_window_expired : #{created_epoch} #{time_interval}")
    time_diff = get_unix_time_diff(created_epoch, get_current_epoch())
    if time_diff > time_interval, do: true, else: false
  end

  def get_current_epoch() do
    {:ok, current_date_time} = DateTime.now("Etc/UTC")
    DateTime.to_unix(current_date_time)
  end

  defp get_unix_time_diff(epoch_init, epoch_final) do
    epoch_final - epoch_init
  end

  def generate_lock_entry(vendor) do
    %{
      "SERVICE_NAME" => %{
        "S" => vendor[:service_name]
      },
      "VENDOR" => %{
        "S" => "initialize"
      },
      "EPOCH" => %{
        "N" => Integer.to_string(get_current_epoch())
      }
    }
  end

  def generate_put_map(property_name, value, epoch \\get_current_epoch()) do
    %{
      "property" => %{
        "S" => property_name
      },
      "value" => %{
        "S" => to_string(value)
      },
      "epoch" => %{
        "N" => Integer.to_string(epoch)
      }
    }
  end

  def generate_dynamodb_json(vendor) do
    %{
      "SERVICE_NAME" => %{
        "S" => vendor[:service]
      },
      "VENDOR" => %{
        "S" => vendor[:vendor]
      },
      "PRIMARY" => %{
        "BOOL" => vendor[:primary]
      },
      "CURRENT" => %{
        "BOOL" => vendor[:current]
      },
      "OV_IN_ACTION" => %{
        "BOOL" => vendor[:ov_in_action]
      },
      "RETRY_COUNT" => %{
        "N" => Integer.to_string(vendor[:retry_count])
      },
      "ERROR_COUNT" => %{
        "N" => Integer.to_string(vendor[:error_count])
      },
      "ERROR_EPOCH" => %{
        "N" => Integer.to_string(vendor[:error_epoch])
      },
      "EPM_COUNT" => %{
        "N" => Integer.to_string(vendor[:epm_count])
      },
      "EPM_EPOCH" => %{
        "N" => Integer.to_string(vendor[:epm_epoch])
      },
      "SUCCESS_COUNT" => %{
        "N" => Integer.to_string(vendor[:success_count])
      },
      "SUCCESS_EPOCH" => %{
        "N" => Integer.to_string(vendor[:success_epoch])
      },
      "TOTAL_COUNT" => %{
        "N" => Integer.to_string(vendor[:total_count])
      }
    }
  end

  def generate_vendor_map_from_db_json(vendorDB) do
    Logger.info("Retry count for #{vendorDB["VENDOR"]["S"]}: #{vendorDB["RETRY_COUNT"]["N"]}")
    vendor_map = %{
      service: vendorDB["SERVICE_NAME"]["S"],
      vendor: vendorDB["VENDOR"]["S"],
      primary: vendorDB["PRIMARY"]["BOOL"],
      current: vendorDB["CURRENT"]["BOOL"],
      ov_in_action: vendorDB["OV_IN_ACTION"]["BOOL"],
      retry_count: String.to_integer(vendorDB["RETRY_COUNT"]["N"]),
      error_count: String.to_integer(vendorDB["ERROR_COUNT"]["N"]),
      error_epoch: String.to_integer(vendorDB["ERROR_EPOCH"]["N"]),
      epm_count: String.to_integer(vendorDB["EPM_COUNT"]["N"]),
      epm_epoch: String.to_integer(vendorDB["EPM_EPOCH"]["N"]),
      success_count: String.to_integer(vendorDB["SUCCESS_COUNT"]["N"]),
      success_epoch: String.to_integer(vendorDB["SUCCESS_EPOCH"]["N"]),
      total_count: String.to_integer(vendorDB["TOTAL_COUNT"]["N"])
    }
    vendor_map
  end
end