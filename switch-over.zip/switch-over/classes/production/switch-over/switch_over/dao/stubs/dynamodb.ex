defmodule DAO.DynamoDBTest do
  require Logger

  def get_item(property) do
    Logger.info("DynamoDBTest | get_item | #{property}")
    case property do
      "pan_service--OV" -> %{"value" => %{"S" => :undefined}, "epoch" => %{"N" => "0"}}
      "pan_service-v1-OV" -> %{"value" => %{"S" => true}, "epoch" => %{"N" => "0"}}
      "pan_service-v1-OV" -> %{"value" => %{"S" => :undefined}, "epoch" => %{"N" => "0"}}
      "pan_service-v1-RTC" -> %{"value" => %{"S" => "3"}, "epoch" => %{"N" => "0"}}
      "pan_service-v2-RTC" -> %{"value" => %{"S" => "0"}, "epoch" => %{"N" => "0"}}
      "pan_service-v2-EC" -> %{"value" => %{"S" => "10"} , "epoch" => %{"N" => to_string(get_current_epoch())}}
      "pan_service-v1-EC" -> %{"value" => %{"S" => "0"} , "epoch" => %{"N" => "0"}}
      "pan_service-v2-TC" -> %{"value" => %{"S" => "10"} , "epoch" => %{"N" => to_string(get_current_epoch())}}
      "pan_service-v1-TC" -> %{"value" => %{"S" => "9"} , "epoch" => %{"N" => to_string(get_current_epoch())}}
      "pan_service-v1-EC" ->  %{"value" => %{"S" => "0"}, "epoch" => %{"N" => "0"}}
      "pan_service-v2-EPM" ->  %{"value" => %{"S" => "10"}, "epoch" => %{"N" => to_string(get_current_epoch)}}
      "pan_service-v1-EPM" ->  %{"value" => %{"S" => "0"}, "epoch" => %{"N" => "0"}}
      "pan_service-v1-SC" -> %{"value" => %{"S" => "10"}, "epoch" => %{"N" => to_string(get_current_epoch())}}
      _ -> %{"value" => %{"S" => "v1"}, "epoch" => %{"N" => "0"}}
    end
  end

  def put_item(item_map) do
    true
  end

  def put_item_if_not_exists(property_map) do
    true
  end

  def delete_item(property) do
    true
  end

  def get_current_epoch() do
      {:ok, current_date_time} = DateTime.now("Etc/UTC")
      DateTime.to_unix(current_date_time)
  end

end