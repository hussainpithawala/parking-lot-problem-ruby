defmodule Service.VendorTest do
  @moduledoc false
  use ExUnit.Case
  use Plug.Test

  test "Get vendor should return" do
    vendor_name = DAO.DB.get_current_vendor_code("pan_service")
    assert vendor_name == "v1"
  end

  test "report_error_and_get_vendor1" do
    vendor_code = "v1"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    reported_vendor_code = Service.Vendor.report_error_and_get_vendor("pan_service", vendor)
    assert vendor_code == reported_vendor_code
  end

  test "report_error_and_get_vendor2" do
    vendor_code = "v2"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    reported_vendor_code = Service.Vendor.report_error_and_get_vendor("pan_service", vendor)
    assert vendor_code == reported_vendor_code
  end

  test "report_timeout_and_get_vendor1" do
    vendor_code = "v1"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    reported_vendor_code = Service.Vendor.report_timeout_and_get_vendor("pan_service", vendor)
    assert vendor[:error_switch_code] == reported_vendor_code
  end

  test "report_timeout_and_get_vendor2" do
    vendor_code = "v2"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    reported_vendor_code = Service.Vendor.report_timeout_and_get_vendor("pan_service", vendor)
    assert vendor[:code] == reported_vendor_code
  end

  test "handle_skipback_case: no_switch" do
    vendor_code = "v1"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    skip_back_case = Service.Vendor.handle_skipback_case(vendor)
    assert skip_back_case == {:no_switch, "v1"}
  end

  test "handle_skipback_case: skip_switch" do
    vendor_code = "v2"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    skip_back_case_response = Service.Vendor.handle_skipback_case(vendor)
    assert skip_back_case_response == {:skip_switch, "v1"}
  end

  test "handle_success_window_expiry" do
    vendor_code = "v2"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    success_window_expiry_response = Service.Vendor.handle_success_window_expiry(vendor)
    assert success_window_expiry_response == {:success_switch, "v1"}
  end

  test "handle_error_window_expiry: error_switch" do
    vendor_code = "v2"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    error_window_expiry_response = Service.Vendor.handle_error_window_expiry(vendor)
    assert error_window_expiry_response == {:error_switch, "v1"}
  end

  test "handle_error_window_expiry: no_switch" do
    vendor_code = "v1"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    error_window_expiry_response = Service.Vendor.handle_error_window_expiry(vendor)
    assert error_window_expiry_response == {:no_switch, "v1"}
  end

  test "handle_error_per_minute_expiry: error_switch" do
    vendor_code = "v2"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    error_per_minute_expiry_response = Service.Vendor.handle_error_per_minute_expiry(vendor)
    assert error_per_minute_expiry_response == {:error_switch, "v1"}
  end

  test "handle_error_per_minute_expiry: no_switch" do
    vendor_code = "v1"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    error_per_minute_expiry_response = Service.Vendor.handle_error_per_minute_expiry(vendor)
    assert error_per_minute_expiry_response == {:no_switch, "v1"}
  end

  test "handle_retry_expiry: no_switch" do
    vendor_code = "v1"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    handle_retry_expiry_response = Service.Vendor.handle_retry_expiry(vendor)
    assert handle_retry_expiry_response == {:no_switch, "v1"}
  end

  test "handle_retry_expiry: retry_switch" do
    vendor_code = "v2"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    handle_retry_expiry_response = Service.Vendor.handle_retry_expiry(vendor)
    assert handle_retry_expiry_response == {:retry_switch, "v1"}
  end
end