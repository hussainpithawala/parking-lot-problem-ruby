set -e
echo "Starting switch-over service"
/usr/src/app/_build/$1/rel/switch_over_service/bin/switch_over_service start