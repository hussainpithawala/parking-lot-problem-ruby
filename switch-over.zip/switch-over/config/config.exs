import Config

config :switch_over_service, :env, Mix.env()
config :switch_over_service, :dynamodb, DAO.DynamoDB
config :logger,
       backends: [
              {JsonLogger.Console, :console}
       ]
config :logger, :console,
       level: :info

config :prometheus, Service.Prometheus.PipelineInstrumenter,
       labels: [:status_class, :method, :host, :scheme, :request_path],
       duration_buckets: [10, 100, 1_000, 10_000, 100_000,
              300_000, 500_000, 750_000, 1_000_000,
              1_500_000, 2_000_000, 3_000_000],
       registry: :default,
       duration_unit: :microseconds

config :elixir, :time_zone_database, Tzdata.TimeZoneDatabase

config :switch_over_service,
        Service.Endpoint,
        port: 4000
#Use for UT
case Mix.env() do
       :test -> import_config "test.exs"
       :test_workflow -> import_config "test.exs"
       _ -> :ok
end