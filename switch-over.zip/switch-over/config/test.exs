import Config

config :switch_over_service, :dynamodb, DAO.DynamoDBTest