defmodule YAMLConfigProvider do
  def load(config_path, secret_path) do
    # We need to start any app we may depend on.
    {
    :ok,
    %{
    "application" => application,
    "keydb" => %{
      "host" => host,
      "port" => port
      },
    "db" => %{
      "region" => region,
      "propertyTable" => propertyTable
      },
    "lockDuration" => lockDuration,
    "isKeyDBRunning" => isKeyDBRunning
      }
    } = Yml.read_from_file(config_path)
    {
    :ok,
    %{
    "db" => %{
       "accessKey" => accessKey,
    "secretAccessKey" => secretAccessKey
    }
    }
    } = Yml.read_from_file(secret_path)
    config_keydb(host, port)
    config_db(accessKey, secretAccessKey, region, propertyTable)
    config_common(lockDuration, isKeyDBRunning)
    config_application(application)
  end

  def config_application(application) do
    Config.config :switch_over_service, Service.Maker, application
  end

  def config_keydb(host, port) do
    host_name = System.get_env("KEYDB_HOST", host)
    port_number = String.to_integer(System.get_env("KEYDB_PORT", Integer.to_string(port)))
    Config.config :redis_connection_pool, [
      host: host_name,
      port: port_number,
      db: 0,
      reconnect: :no_reconnect,
      pool_name: :"Redis.Pool",
      pool_size: 10,
      pool_max_overflow: 1
    ]
  end

  def config_db(accessKey, secretAccessKey, region, propertyTable) do
    Config.config :aws , [
      accessKey: accessKey,
      secretAccessKey: secretAccessKey,
      region: region,
      propertyTable: propertyTable
    ]
  end

  def config_common(lockDuration, isKeyDBRunning) do
    Config.config :switch_over_service, [
      lock_duration: lockDuration,
      is_keydb_running: isKeyDBRunning
    ]
  end
end

env = Application.get_env(:switch_over_service, :env)
#env defines the config file and path to be loaded.
case env do
  :test -> YAMLConfigProvider.load("test/config/#{env}.yml", "test/secret/#{env}.yml")              # to run tests locally
  :test_workflow -> YAMLConfigProvider.load("test/config/#{env}.yml", "test/secret/#{env}.yml")     # to run tests in the github workflow
  _ -> if File.exists?("/config/#{env}.yml") && File.exists?("/secret/#{env}.yml") do
         YAMLConfigProvider.load("/config/#{env}.yml", "/secret/#{env}.yml")
       else
         if File.exists?("config/#{env}.yml") && File.exists?("secret/#{env}.yml") do
           YAMLConfigProvider.load("config/#{env}.yml", "secret/#{env}.yml")
         end
       end
end