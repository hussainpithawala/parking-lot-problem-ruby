defmodule SwitchOver.MixProject do
  use Mix.Project

  def project do
    [
      app: :switch_over_service,
      version: "0.1.0",
      elixir: "~> 1.12",
      start_permanent: Mix.env() == :prod,
      deps: deps()
    ]
  end

  # Run "mix help compile.app" to learn about applications.
  def application do
    [
      extra_applications: [:logger, :prometheus_ex, :prometheus_process_collector, :redix],
      mod: {SwitchOver.Application, []}
    ]
  end

  # Run "mix help deps" to learn about dependencies.
  defp deps do
    [
      {:configparser_ex, "~> 4.0"},
#      {:redis_connection_pool, "~> 0.1.5"},
      {:plug_cowboy, "~> 2.0"},
      {:timex, "~> 3.0"},
      {:wannabe_bool, "~> 0.1"},
      {:mock, "~> 0.3.0", only: :test},
      {:uuid, "~>1.1"},
      {:prometheus_ex, "~> 3.0.5"},
      {:prometheus_plugs, "~> 1.1.5"},
      {:prometheus_process_collector, "~> 1.6.0"},
      {:prometheus_cowboy, "~> 0.1.8"},
      {:yml, "~> 0.9.1"},
      {:poison, "~> 5.0"},
      {:aws, "~> 0.9.0"},
      {:hackney, "~> 1.17"},
      {:redix, "~> 1.1"},
      {:castore, ">= 0.0.0"}
    ]
  end

end

