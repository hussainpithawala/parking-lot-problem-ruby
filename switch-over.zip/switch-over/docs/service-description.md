# "Switch Over" utility
### Description

A library to help switch to different vendors on the basis of the given criteria

### Configuration Parameters

###Services
Defines a set of services, which are under the ambit of switch over

### Vendors
A vendor is a 3rd party service to whom we may reach out for a request. In the event of continuous
failures, we might need to switch over to a different vendor.

###### Properties
- **primary**
    - A boolean field indicating whether a vendor is declared primary or not.
-  **code**
    - A value indicating the code of the vendor. It is a coupling with the same key-value in the consumer-config.json.
      On the basis of this field, the consumer can switch to a different vendor service.
- **retry**
    - Number of attempts to make in succession for a particular call in case we receive a 5XX error. When application is
      initialized or first call is received( Depends whether we are preparing context lazily or eagerly) set the key-value
      in keydb server with this parameter in the following format. "pan_service-v1-RC".
      Before making a call to the vendor check if the value for this key is 0.In case,
        - Yes, switch over temporarily for this request to other vendor and reinitialize the key-value pair with the
          configuration value.
        - No, decrement this counter by 1 and continue using the same vendor.
- **error_window**
    - The error_observability window is defined in seconds during, which we increment the error counter.
      When first call is received, for any vendor get the current time stamp and add this value.
      Persist it with following key in the keydb-server in the following format. "pan_service-v1-EW".
        - Case-1: In case time has not lapsed and trigger_switch_error_count is greater than error_counter. Reset, the
          error_counter ("pan_service-v1-EC") for the vendor to 0 in keydb server and switch over to
          another vendor.
        - Case-2: In case time has lapsed and trigger_switch_error_count is less than error_counter. Reset, the
          error_counter ("pan_service-v1-EC") for the vendor to 0 in keydb server and continue using the same vendor.
-  **trigger_switch_error_count**
    - The number of error count if exceeded within a given time window (the expiry measured using
      error_window), calls for switch over to another vendor. Error count has to be persisted in the redis
      in the following format <service_name>-<vendor_code>-EC, where EC stands for the error count.
      For e.g. "pan_service-v1-EC".+
-  **trigger_switch_success_count**
    - The number of success counts(for a primary-vendor) if exceeded within a given time window (the expiry measured using
      success_window), calls for switch over to another vendor. Error count has to be persisted in the redis
      in the following format <service_name>-<vendor_code>-SC, where SC stands for the success count.
      For e.g. "pan_service-v1-SC".
- **success_window**
    - The success_window is created akin to error_window. Except that this window is used to measure the performance of
      the primary vendor while secondary vendor is used. This parameter is used along with the **skip_back_counter**
      parameter. PS: that success observability is not measured for primary vendor, since it is the preferred vendor.
- **skip_back_counter**
    - This counter indicates that after how many successful attempts to a non-primary vendor, we should try and check
      whether primary vendor is up and responding back, while we are working within a different vendor's
      **success_window**. This is done to ensure that periodically we are checking whether primary vendor is
      up or not.

#### Example configuration for library

```json
{
  "global": {
    "retry": 3,
    "error_window": 60,
    "success_window": 60,
    "trigger_switch_error_count": 5,
    "skip_back_counter": 5
  },
  "services": [
    {
      "service_name": "pan_service",
      "vendors": [
        {
          "primary": true,
          "code": "v1",
          "retry": 3,
          "error_window": 30,
          "trigger_switch_error_count": 5,
          "skip_back_counters": 5
        },
        {
          "code": "v2",
          "retry": 3,
          "error_window": 30,
          "trigger_switch_error_count": 5,
          "trigger_switch_success_count": 5,
          "skip_back_counters": 5
        }
      ]
    }
  ]
}
```

#### Example configuration for service
```json
{
  "services": [
    {
      "service": "pan-service",
      "vendors": [
        {
          "code": "v1",
          "url": "https://nsdl.com"
        },
        {
          "code": "v2",
          "url": "https://karza.com"
        }
      ]
    }
  ]
}
```

### Key-Values in action with examples

#### Consider application is initialized and primary vendor is in action

- "pan_service-current-vendor" = "v1"
    - Vendor code of the current vendor

- "pan_service-other-vendor" = "v2"
    - Vendor code of the other vendor, to whom we may switch-over

- "pan_service-v1-RC" = **retry**
    - this is decremented on successive retries and once set to zero we temporarily return
      the other vendor code. Reset this back to value of **retry** after switching back to the current vendor

- "pan_service-v1-EC" = error counter for current vendor

- "pan_service-v1-EW" = "2021-06-14T17:48:02+05:30"
    - The error window is computed using current time stamp + **error_window** as number of seconds

In case, this window ("pan_service-v1-EW") is breached, then we have to consider the following two cases:
##### Case-1: "pan_service-v1-EC" > **trigger_switch_error_count**
    Switch over to secondary vendor
##### Case-2: "pan_service-v1-EC" < **trigger_switch_error_count**
    Reset the "pan_service-v1-EC" to zero.
    Reset the "pan_service-v2-EW" to current time stamp + **error_window**
    Continue using the current vendor


#### Consider application has switched over to secondary vendor

- "pan_service-current-vendor" = "v2"
    - Vendor code of the current vendor

- "pan_service-other-vendor" = "v1"
    - Vendor code of the other vendor, to whom we may switch-over

- "pan_service-v2-RC" = **retry**
    - This is decremented on successive retries and once set to zero we temporarily return the other vendor code.
      Reset this back to value of **retry** after switching back to the current vendor

- "pan_service-v2-EC" = error counter for current vendor

- "pan_service-v1-SC" = success counter for other vendor
    - this is to keep track of requests made to primary vendor, when
      actual vendor in use is the secondary vendor

- "pan_service-v2-EW" = "2021-06-14T17:48:02+05:30"
    - The error window is computed using current time stamp + **error_window** as number of seconds

The success window is computed using current time stamp + **success_window** as number of seconds. We repeatedly check
through the **skip_back_counter** whether v1 vendor is healthy or not, within the time frame of this window.
"pan_service-v2-SW" = "2021-06-14T17:48:02+05:30"jest-dynamodb-config.jsmodule.exports={};

In case, this window ("pan_service-v2-SW") is breached, then we have to consider the following two cases:
##### Case-1: "pan_service-v1-SC" > **trigger_switch_success_count**
    Switch over to primary vendor
##### Case-2: "pan_service-v1-SC" < **trigger_switch_success_count**
    Reset the "pan_service-v1-SC" to zero.
    Reset the "pan_service-v2-SW" to current time stamp + **success_window**
    Continue using the current vendor

Apart from this for secondary vendor the **error_window** logic also holds true. So, in case any of these conditions are
valid we switch over to the primary vendor from secondary.


### Transient cases
These case help us to switch over to other vendor temporarily in case of sudden glitch. Yet, if the problem persists
we switch over to other vendor.

#### Case-1
    For subsequent retries if there is a failure and "pan_service-v1-RC" or "pan_service-v2-RC" is set to zero, 
    temporarily return the other vendor code and set the "pan_service-v1-RC" or "pan_service-v2-RC" to the value of 
    **retry** parameter for that vendor. Also, "pan_service-v1-EC" or "pan_service-v2-EC" will be incremented.
    The value of the counter "pan_service-v1-RC" or "pan_service-v2-RC" is decremented on try after failures.
#### Case-2
    In case a timeout is reported, return the other vendor code. Remember, all failures including timeout will lead to 
    incrementing "pan_service-v1-EC" or "pan_service-v2-EC" in the error window.
