defmodule Experiment.ServiceTest do
  @moduledoc false
  use ExUnit.Case
  use Plug.Test

  test "Return current implementation" do
    impl = Experiment.Service.get_impl("workflow", "PLCREDI")
    assert impl == "Elastit"
  end

  test "Return experiment implementation" do
    impl = Experiment.Service.get_impl("workflow", "PLCREDI2")
    assert impl == "Workflow"
  end

  test "Get Execution Status: True if wf_config_count != 0" do
    impl = Experiment.Service.get_running_status("experiment", "PL_LOC")
    assert impl == "true"
  end

  test "Get Execution Status: False if wf_config_count == 0" do
    impl = Experiment.Service.get_running_status("experiment", "PL_CREDI")
    assert impl == "false"
  end
end