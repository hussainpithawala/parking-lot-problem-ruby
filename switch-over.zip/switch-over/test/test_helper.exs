ExUnit.start()
Application.ensure_all_started(:timex)