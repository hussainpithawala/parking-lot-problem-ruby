defmodule EndpointTest do
  use ExUnit.Case
  use Plug.Test

  alias Service.Endpoint

  @moduletag :capture_log

  @options Endpoint.init([])

  test "module exists" do
    assert is_list(Endpoint.module_info())
  end

  test "should return text for base url" do
    conn = conn("get", "")
           |> Endpoint.call(@options)
    assert conn.state == :sent
    assert conn.status == 200
    assert conn.resp_body == "Try /svc/get_vendor/<service_name> to fetch the vendor"
  end
end
