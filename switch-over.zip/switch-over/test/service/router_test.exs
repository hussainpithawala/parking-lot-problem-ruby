defmodule Service.RouterTest do
  @moduledoc false

  use ExUnit.Case
  use Plug.Test

  alias Service.Router

  @options Router.init([])

  test "module exists" do
    assert is_list(Router.module_info())
  end

  test "should return text for base url" do
    conn = conn("get", "get_vendor/pan_service")
    |> Router.call(@options)
    assert conn.state == :sent
    assert conn.status == 200
    assert conn.resp_body == "NSDL"
  end
end
