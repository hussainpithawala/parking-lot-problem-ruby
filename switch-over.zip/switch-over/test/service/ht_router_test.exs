defmodule Service.HtRouterTest do
  use ExUnit.Case
  use Plug.Test

  alias Service.HtRouter

  test "module exists" do
    assert is_list(HtRouter.module_info())
  end

  @options HtRouter.init([])

  test "should return text for health-check" do
    conn = conn("get", "")
           |> HtRouter.call(@options)
    assert conn.state == :sent
    assert conn.status == 200
    assert conn.resp_body == "Hello from switch_over_service"
  end

end
