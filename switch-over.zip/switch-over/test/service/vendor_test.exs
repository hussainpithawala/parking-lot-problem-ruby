defmodule Service.VendorTest do
  @moduledoc false
  use ExUnit.Case
  use Plug.Test

  test "Get vendor should return" do
    vendor = DAO.DB.get_vendor("pan_service", "NSDL")
    assert vendor[:vendor] == "NSDL"
  end

  test "report_error_and_get_vendor1" do
    vendor_code = "NSDL"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    reported_vendor_code = Service.Vendor.report_error_and_get_vendor("pan_service")
    assert vendor_code == reported_vendor_code
  end

  test "report_error_and_get_vendor2" do
    vendor_code = "NSDL"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    reported_vendor_code = Service.Vendor.report_error_and_get_vendor("pan_service")
    assert vendor_code == reported_vendor_code
  end

  test "report_timeout_and_get_vendor1" do
    vendor_code = "NSDL"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    reported_vendor_code = Service.Vendor.report_timeout_and_get_vendor("pan_service")
    assert vendor[:error_switch_code] == reported_vendor_code
  end

  test "report_timeout_and_get_vendor2" do
    vendor_code = "Karza"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    reported_vendor_code = Service.Vendor.report_timeout_and_get_vendor("pan_service")
    assert vendor[:code] == reported_vendor_code
  end

  test "handle_skipback_case: no_switch" do
    vendor_code = "NSDL"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
    service: "pan_service",
    vendor: "NSDL",
    primary: true,
    current: true,
    ov_in_action: false,
    retry_count: 10,
    error_count: 0,
    error_epoch: 0,
    epm_count: 0,
    epm_epoch: 0,
    success_count: 0,
    success_epoch: 0,
    total_count: 2
    }
    skip_back_case = Service.Vendor.handle_skipback_case(vendor, vendor_map )
    assert skip_back_case == {:no_switch, "NSDL"}
  end

  test "handle_skipback_case: skip_switch" do
    vendor_code = "Karza"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
      service: "pan_service",
      vendor: "Karza",
      primary: true,
      current: true,
      ov_in_action: false,
      retry_count: 10,
      error_count: 0,
      error_epoch: 0,
      epm_count: 0,
      epm_epoch: 0,
      success_count: 0,
      success_epoch: 0,
      total_count: 5
    }
    skip_back_case_response = Service.Vendor.handle_skipback_case(vendor, vendor_map)
    assert skip_back_case_response == {:skip_switch, "NSDL"}
  end

  test "handle_success_window_expiry" do
    vendor_code = "Karza"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
      service: "pan_service",
      vendor: "Karza",
      primary: true,
      current: true,
      ov_in_action: false,
      retry_count: 10,
      error_count: 0,
      error_epoch: 0,
      epm_count: 0,
      epm_epoch: 0,
      success_count: 10,
      success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 5
    }
    success_window_expiry_response = Service.Vendor.handle_success_window_expiry(vendor, vendor_map)
    assert success_window_expiry_response == {:success_switch, "NSDL"}
  end

  test "handle_error_window_expiry: error_switch" do
    vendor_code = "Karza"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
      service: "pan_service",
      vendor: "Karza",
      primary: true,
      current: true,
      ov_in_action: false,
      retry_count: 10,
      error_count: 10,
      error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0,
      epm_epoch: 0,
      success_count: 10,
      success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 5
    }
    error_window_expiry_response = Service.Vendor.handle_error_window_expiry(vendor, vendor_map)
    assert error_window_expiry_response == {:error_switch, "AuthBridge"}
  end

  test "handle_error_window_expiry: no_switch" do
    vendor_code = "NSDL"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
      service: "pan_service",
      vendor: "NSDL",
      primary: true,
      current: true,
      ov_in_action: false,
      retry_count: 10,
      error_count: 0,
      error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0,
      epm_epoch: 0,
      success_count: 10,
      success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 5
    }
    error_window_expiry_response = Service.Vendor.handle_error_window_expiry(vendor, vendor_map)
    assert error_window_expiry_response == {:no_switch, "NSDL"}
  end

  test "handle_error_per_minute_expiry: error_switch" do
    vendor_code = "Karza"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
      service: "pan_service",
      vendor: "Karza",
      primary: true,
      current: true,
      ov_in_action: false,
      retry_count: 10,
      error_count: 0,
      error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 10,
      epm_epoch: DAO.DBUtil.get_current_epoch(),
      success_count: 10,
      success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 5
    }
    error_per_minute_expiry_response = Service.Vendor.handle_error_per_minute_expiry(vendor, vendor_map)
    assert error_per_minute_expiry_response == {:error_switch, "AuthBridge"}
  end

  test "handle_error_per_minute_expiry: no_switch" do
    vendor_code = "NSDL"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
      service: "pan_service",
      vendor: "NSDL",
      primary: true,
      current: true,
      ov_in_action: false,
      retry_count: 10,
      error_count: 0,
      error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0,
      epm_epoch: DAO.DBUtil.get_current_epoch(),
      success_count: 10,
      success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 5
    }
    error_per_minute_expiry_response = Service.Vendor.handle_error_per_minute_expiry(vendor, vendor_map)
    assert error_per_minute_expiry_response == {:no_switch, "NSDL"}
  end

  test "handle_retry_expiry: no_switch" do
    vendor_code = "NSDL"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
      service: "pan_service",
      vendor: "NSDL",
      primary: true,
      current: true,
      ov_in_action: false,
      retry_count: 10,
      error_count: 0,
      error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0,
      epm_epoch: DAO.DBUtil.get_current_epoch(),
      success_count: 10,
      success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 5
    }
    handle_retry_expiry_response = Service.Vendor.handle_retry_expiry(vendor, vendor_map)
    assert handle_retry_expiry_response == {:no_switch, "NSDL"}
  end

  test "handle_retry_expiry: retry_switch" do
    vendor_code = "Karza"
    vendor = Service.Vendor.get_vendor_from_ets("pan_service", vendor_code)
    vendor_map = %{
      service: "pan_service",
      vendor: "Karza",
      primary: true,
      current: true,
      ov_in_action: false,
      retry_count: 0,
      error_count: 0,
      error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0,
      epm_epoch: DAO.DBUtil.get_current_epoch(),
      success_count: 10,
      success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 5
    }
    handle_retry_expiry_response = Service.Vendor.handle_retry_expiry(vendor, vendor_map)
    assert handle_retry_expiry_response == {:retry_switch, "AuthBridge"}
  end
end