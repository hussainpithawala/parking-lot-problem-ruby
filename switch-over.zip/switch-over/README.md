# Switch-Over
This service is used to heuristically choose a vendor from configuration.
## Motivation
This service is developed to be used along with Janus and Hermes to choose vendor out of multiple vendors.
## Reference
In-depth explanation of algorithm and heuristics : [Presentation](https://docs.google.com/presentation/d/1UjsABfOownJrXSua5JwtMms6bZF5sNcge5GzumbxV5M/edit?usp=sharing)
## Startup
1. Get config file(change name to your env) and paste to config folder.Exp: secret/qa-dedupe.yml
2. Get secret file(change name to your env) and paste to secret directory(if not present ,create one).Exp: secret/qa-dedupe.yml
3. Change the redis endpoint to localhost.
4. Run following commands:
    ```shell
    mix deps.get
    MIX_ENV=<env-name> mix run --no-halt
   ```
   
## Build status
[![CICD](https://github.com/archive-repo/switch-over/actions/workflows/nprod.yml/badge.svg)](https://github.com/archive-repo/switch-over/actions/workflows/nprod.yml)
## Modules Explaination
### logging
Logger backend code to convert text logging to json format in order to use it on Kibana.
### service
Contains 3 layers :
1. Endpoint : This is where api call is made.
2. Vendor : This is where the logic is written(Service layer)
3. Redis : This is the DB layer , from where we read and write data to or from Redis.
### spawn
Uses multiple processes to run multiple functions over a value or multiple values over a function parallely
## Installation
If [available in Hex](https://hex.pm/docs/publish), the package can be installed
by adding `switch_over` to your list of dependencies in `mix.exs`:

```elixir
def deps do
  [
    {:switch_over, "~> 0.1.0"}
  ]
end
```

Documentation can be generated with [ExDoc](https://github.com/elixir-lang/ex_doc)
and published on [HexDocs](https://hexdocs.pm). Once published, the docs can
be found at [https://hexdocs.pm/switch_over](https://hexdocs.pm/switch_over).

