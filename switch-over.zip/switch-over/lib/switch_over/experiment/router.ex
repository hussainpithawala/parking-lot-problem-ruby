defmodule Experiment.Router do
  @moduledoc false

  use Plug.Router
  require Logger
  plug(:match)
  plug(:dispatch)

  get("/impl/:function/:loan_scheme", do: get_impl(function, loan_scheme, conn))
  get("/update/impl/:function/:loan_scheme/:value", do: update_config(function, loan_scheme, value, conn))
  get("/get_experiment_implementation_status/:function/:loan_scheme", do: get_status(function, loan_scheme, conn))



  @doc """
  Gets the vendor for provided service
  """
  defp get_impl(function, loan_scheme, conn) do
    impl = Experiment.Service.get_impl(function, loan_scheme)
    conn
    |> put_resp_content_type("text/plain")
    |> send_resp(200, impl)
  end

  @doc """
  Gets the vendor for provided service
  """
  defp update_config(function, loan_scheme, value, conn) do
    impl = Experiment.Service.update_config(function, loan_scheme, value)
    conn
    |> put_resp_content_type("text/plain")
    |> send_resp(200, impl)
  end

  @doc """
  Gets the current running status of Experiment. If WF is running,
  it returns true, else it returns false
  """
  defp get_status(function, loan_scheme, conn) do
    Logger.info("/get_experiment_implementation_status: #{function}, #{loan_scheme}")
    running_status = Experiment.Service.get_running_status(function, loan_scheme)
    conn
    |> put_resp_content_type("text/plain")
    |> send_resp(200, running_status)
  end








end