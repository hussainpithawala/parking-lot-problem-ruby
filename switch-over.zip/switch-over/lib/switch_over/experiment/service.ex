defmodule Experiment.Service do
  @moduledoc false
  require Logger

  def get_impl(function, loan_scheme) do
    #1. Get entry
    experiment_map = DAO.DAOImpl.get_experiment_entry(function, loan_scheme)
    #2. Compare
    wf_config_count = experiment_map[:wf_config_count]
    wf_count = experiment_map[:wf_count]
    Logger.info("Workflow count : #{wf_count} and Workflow Config count : #{wf_config_count}")
    impl = if(wf_config_count == 0) do
      Logger.info("Config Count : #{wf_config_count}")
      experiment_map[:cur_impl]
    else
      if(wf_config_count == 0 || rem(wf_count, wf_config_count) == 0) do
        Logger.info("Returning experimental implementation : #{experiment_map[:exp_impl]}")
        experiment_map[:exp_impl]
      else
        Logger.info("Returning current implementation : #{experiment_map[:cur_impl]}")
        experiment_map[:cur_impl]
      end
    end
    #3. Update entry
    wf_count = wf_count+1
    experiment_map = %{experiment_map | wf_count: wf_count}
    DAO.DAOImpl.set_experiment_entry(experiment_map)
    #4. Return impl
    impl
  end

  def update_config(function, loan_scheme, value) do
    Logger.info("Starting update config #{function}, #{loan_scheme} to #{value}")
    #1. Get entry
    experiment_map = DAO.DAOImpl.get_experiment_entry(function, loan_scheme)
    Logger.info("Current config value #{experiment_map[:wf_config_count]}")
    #2. update config value
    wf_config_value_updated = String.to_integer(value)
    experiment_map = %{experiment_map | wf_config_count: wf_config_value_updated}
    #3. Insert to DAO
    DAO.DAOImpl.set_experiment_entry(experiment_map)
    Logger.info("Updated config value")
    "true"
  end

  @doc """
  Method that gets the experiment entry, and then checks whether or not experiment is running
  """
  def get_running_status(function, loan_scheme) do
    Logger.info("get_running_status: Running Status for #{function}, #{loan_scheme}")
    #1. Get entry
    experiment_map = DAO.DAOImpl.get_experiment_entry(function, loan_scheme)
    Logger.info("get_workflow_status: Current config value is #{experiment_map[:wf_config_count]}")
    #2. Checker method to check the value of the config
    checker =
      cond do
        experiment_map[:wf_config_count] == 0 -> "false"
        true -> "true"
      end
    response = checker
    Logger.info("get_running_status: Status is #{response}")
    #3. Return the response
    response
  end
end
