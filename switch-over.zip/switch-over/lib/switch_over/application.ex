defmodule SwitchOver.Application do
  # See https://hexdocs.pm/elixir/Application.html
  # for more information on OTP Applications
  @moduledoc false

  use Application
  require Logger

  @impl true
  def start(_type, _args) do

    children = [
      # Starts a worker by calling: SwitchOver.Worker.start_link(arg)
      # {SwitchOver.Worker, arg}
      {Service.Endpoint, []},
      {RedixPool, []}
    ]

    # See https://hexdocs.pm/elixir/Supervisor.html
    # for other strategies and supported options
    opts = [strategy: :one_for_one, name: SwitchOver.Supervisor]
    {result, params} = Supervisor.start_link(children, opts)
    case result do
      :ok -> wrap_extras()
             {result, params}
      _ -> {result, params}
    end
  end

  def wrap_extras() do
    # Initialize prometheus exporters
    prometheus_init()

    # initializes the configuration values in the term storage so that processes can refer to these
    Service.Maker.init()
  end

  def prometheus_init() do
    Service.Prometheus.PipelineInstrumenter.setup()
    Prometheus.Registry.register_collector(:prometheus_process_collector)
    Service.Prometheus.PrometheusExporter.setup()
  end
end
