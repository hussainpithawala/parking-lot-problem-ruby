defmodule Service.Router do
  @moduledoc false

  use Plug.Router
  require Logger
  plug(:match)
  plug(:dispatch)

  get("/get_vendor/:service", do: current_vendor(service, conn))

  get("/report_error/:service/:issue", do: report_error(service, issue, conn))

  @doc """
  Gets the vendor for provided service
  """
  defp current_vendor(service, conn) do
    current_vendor = Service.Vendor.get_vendor(service)
    conn
    |> put_resp_content_type("text/plain")
    |> send_resp(200, current_vendor)
  end

  defp report_error(service, issue, conn) do
    vendor_code = case issue do
      "timeout" -> Service.Vendor.report_timeout_and_get_vendor(service)
      "error" -> Service.Vendor.report_error_and_get_vendor(service)
      _ -> Service.Vendor.get_vendor(service)
    end

    conn
    |> put_resp_content_type("text/plain")
    |> send_resp(200, vendor_code)
  end

end