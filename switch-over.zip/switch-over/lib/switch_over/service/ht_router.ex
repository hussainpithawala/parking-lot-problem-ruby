defmodule Service.HtRouter do
  @moduledoc false

  use Plug.Router
  require Logger

  plug(:match)
  plug(:dispatch)

  get "/" do
    conn
    |> put_resp_content_type("text/plain")
    |> send_resp(200, message())
  end

  defp message, do: "Hello from switch_over_service"
end
