defmodule Service.Vendor do
  @moduledoc false

  require Logger

  @doc """
  get current vendor and call overloaded method.
  """
  def report_error_and_get_vendor(service_name) do
    vendor_list = DAO.DAOImpl.get_all_vendors_for_provided_service(service_name)
    current_vendor_map = Util.CommonUtil.get_current_vendor(vendor_list)
    current_vendor_map = if(current_vendor_map==:undefined || current_vendor_map==:nil) do
      primary_vendor_name = initialize_primary_vendor(service_name)
      DAO.DAOImpl.get_vendor(service_name, primary_vendor_name)
      else
        current_vendor_map
    end
    current_vendor_code = current_vendor_map[:vendor]
    vendor_config = get_vendor_from_ets(service_name, current_vendor_code)
    report_error_and_get_vendor(service_name, vendor_config, current_vendor_map)
  end

  def initialize_primary_vendor(service_name) do
    vendor_name_list = get_from_ets("#{service_name}-vendors")
    primary_vendor_name = Enum.find( vendor_name_list, fn vendor_name ->
      vendor_details = get_vendor_from_ets(service_name, vendor_name)
      vendor_details[:primary] == true
    end)
    Logger.info("Primary vendor : #{primary_vendor_name}")
    primary_vendor = get_vendor_from_ets(service_name, primary_vendor_name)
    DAO.DAOImpl.initialize_vendor(primary_vendor)
    primary_vendor_name
  end

  def get_from_ets(key) do
    Logger.info("looking for #{key}")
    # load vendor from ets
    [record | _] = :ets.lookup(:service_vendors, "#{key}")
    elem(record, 1)
  end

  def report_error_and_get_vendor(_, %{:sole_vendor => true, :code => code}, vendor_map) do
    code
  end

  @doc """
  Get current skip-back vendor.
  if other vendor is in action, then return the current vendor after
  decrementing success counter for skip_back_vendor and update the current vendor.
  """
  def report_error_and_get_vendor(service_name, %{:sole_vendor => false} = vendor_config, vendor_map) do
    other_vendor_in_action = vendor_map[:ov_in_action]
    if other_vendor_in_action do
      Logger.info("report_error_and_get_vendor  | other_vendor_in_action : #{other_vendor_in_action}")
      Task.async(
        fn  ->
          success_counter = Util.CommonUtil.get_success_counter(vendor_config, vendor_map)
          success_counter = if success_counter==0 do
            success_counter
          else
            success_counter-1
          end
          total_counter = vendor_map[:total_count] + 1
          success_epoch = Util.CommonUtil.get_success_epoch(vendor_config, vendor_map)
          vendor_map = %{vendor_map| success_count: success_counter}
          vendor_map = %{vendor_map| ov_in_action: false}
          vendor_map = %{vendor_map| total_count: total_counter}
          DAO.DAOImpl.put_vendor(vendor_map)
        end)
      vendor_config[:code]
    else
      # increment error counter in the background
      error_counter = Util.CommonUtil.get_error(vendor_config, vendor_map)+1
      error_epoch = Util.CommonUtil.get_error_epoch(vendor_config, vendor_map)
      epm_counter = Util.CommonUtil.get_epm(vendor_config, vendor_map)+1
      epm_epoch = Util.CommonUtil.get_epm_epoch(vendor_config, vendor_map)
      vendor_map = %{vendor_map |  error_count: error_counter}
      vendor_map = %{vendor_map | error_epoch: error_epoch}
      vendor_map = %{vendor_map |  epm_count: epm_counter}
      vendor_map = %{vendor_map | epm_epoch: epm_epoch}
      vendor_code = handle_error_conditions(vendor_config, vendor_map)
      Logger.info("Current value of Vendor #{vendor_map[:vendor]} -->  #{vendor_map[:current]}")
#      if vendor_map[:vendor] != vendor_code do
#        vendor_map = %{vendor_map | current: false}
#        DAO.DAOImpl.put_vendor(vendor_map)
#        update_total_counter_in_background(service_name, vendor_code)
#      else
        total_counter = vendor_map[:total_count]
        vendor_map = %{vendor_map | total_count: total_counter+1}
        DAO.DAOImpl.put_vendor(vendor_map)
#      end
      vendor_code
    end
  end

  def report_timeout_and_get_vendor(service_name) do
    vendor_list = DAO.DAOImpl.get_all_vendors_for_provided_service(service_name)
    current_vendor = Util.CommonUtil.get_current_vendor(vendor_list)
    current_vendor= if(current_vendor==:undefined || current_vendor==:nil) do
      primary_vendor_name = initialize_primary_vendor(service_name)
      DAO.DAOImpl.get_vendor(service_name, primary_vendor_name)
    else
      current_vendor
    end
    current_vendor_code = current_vendor[:vendor]
    vendor_config = get_vendor_from_ets(service_name, current_vendor_code)
    report_timeout_and_get_vendor(service_name, vendor_config, current_vendor)
  end

  def report_timeout_and_get_vendor(_, %{:sole_vendor => true, :code => code}, vendor_map) do
    code
  end

  defp handle_error_conditions(vendor_config, vendor_map) do
    if vendor_config[:primary] do
      handle_conditions_in_parallel(
        [
          &Service.Vendor.handle_error_window_expiry/2,
          &Service.Vendor.handle_error_per_minute_expiry/2,
          &Service.Vendor.handle_retry_expiry/2
        ],
        vendor_config, vendor_map
      )
    else
      handle_conditions_in_parallel(
        [
          &Service.Vendor.handle_error_window_expiry/2,
          &Service.Vendor.handle_error_per_minute_expiry/2,
          &Service.Vendor.handle_success_window_expiry/2,
          &Service.Vendor.handle_retry_expiry/2
        ],
        vendor_config, vendor_map
      )
    end
  end

  def report_timeout_and_get_vendor(service_name, %{:sole_vendor => false} = vendor_config, vendor_map) do
    other_vendor_in_action = vendor_map[:ov_in_action]
    vendor_code = if other_vendor_in_action do
#      Task.async(
#        fn  ->
          success_counter = Util.CommonUtil.get_success_counter(vendor_config, vendor_map)
          success_counter = if success_counter==0 do
            success_counter
            else
              success_counter-1
          end
          total_counter = vendor_map[:total_count] + 1
          success_epoch = Util.CommonUtil.get_success_epoch(vendor_config, vendor_map)
          vendor_map = %{vendor_map| success_count: success_counter}
          vendor_map = %{vendor_map| ov_in_action: false}
          vendor_map = %{vendor_map| total_count: total_counter}
          DAO.DAOImpl.put_vendor(vendor_map)
#        end)
      vendor_config[:code]
    else
      Logger.info("Return other vendor")
#      Task.async(fn  ->
        error_counter = Util.CommonUtil.get_error(vendor_config, vendor_map)+1
        error_epoch = Util.CommonUtil.get_error_epoch(vendor_config, vendor_map)
        epm_counter = Util.CommonUtil.get_epm(vendor_config, vendor_map)+1
        epm_epoch = Util.CommonUtil.get_epm_epoch(vendor_config, vendor_map)
        vendor_map = %{vendor_map |  error_count: error_counter}
        vendor_map = %{vendor_map | error_epoch: error_epoch}
        vendor_map = %{vendor_map |  epm_count: epm_counter}
        vendor_map = %{vendor_map | epm_epoch: epm_epoch}
        DAO.DAOImpl.put_vendor(vendor_map)
#      end)
      current_vendor_code = handle_error_conditions(vendor_config, vendor_map)
      Logger.info("Current vendor code is  : #{current_vendor_code}")
      current_vendor = get_vendor_from_ets(service_name, current_vendor_code)
      current_vendor[:error_switch_code]
    end
    update_total_counter_in_background(service_name, vendor_code)
    vendor_code
  end

  @doc """
  Steps:
  1. Get the current vendor from Redis
  2. Get the vendor details from ets.
  3. call get_vendor
  """
  def get_vendor(service_name) do
    Logger.info("get vendor normal")
    vendor_list = DAO.DAOImpl.get_all_vendors_for_provided_service(service_name)
    current_vendor = Util.CommonUtil.get_current_vendor(vendor_list)

    case current_vendor do
      :undefined || :nil ->
        primary_vendor_name = initialize_primary_vendor(service_name)
        DAO.DAOImpl.get_vendor(service_name, primary_vendor_name)
      _ -> current_vendor
    end
#    current_vendor = if(current_vendor==:undefined || current_vendor==:nil) do
#      primary_vendor_name = initialize_primary_vendor(service_name)
#      DAO.DAOImpl.get_vendor(service_name, primary_vendor_name)
#    else
#      current_vendor
#    end
    current_vendor_code = current_vendor[:vendor]
    Logger.info("Current Vendor Code : #{current_vendor_code}")
    vendor_config = get_vendor_from_ets(service_name, current_vendor_code)
    get_vendor(service_name, vendor_config, current_vendor)
  end

  @doc """
  Method call if provided vendor is the sole vendor in the service.
  It simply returns the vendor code.
  """
  defp get_vendor(_, %{:sole_vendor => true} = vendor_config, vendor) do
    vendor_config[:code]
  end

  @doc """
  Method is called if provided vendor is not the only vendor
  in the service.
  Steps:
  1. checks if the provided vendor is primary vendor:
    i) handle 2 conditions in parallel
    (error_window_expiry and error_per_minute_expiry)
  2. else :
    i)  handle 3 conditions in parallel
    (error_window_expiry, error_per_minute_expiry, success_window_expiry)
  3. set the vendor_code as output from handle_conditions_in_parallel
  4. Update the total count for this vendor.
  5. return the vendor_code
  """
  defp get_vendor(service_name, %{:sole_vendor => false} = vendor_config, vendor_map) do
    vendor_code = if vendor_config[:primary] do
      handle_conditions_in_parallel(
        [
          &Service.Vendor.handle_error_window_expiry/2,
          &Service.Vendor.handle_error_per_minute_expiry/2,
        ],
        vendor_config, vendor_map
      )

    else
      handle_conditions_in_parallel(
        [
          &Service.Vendor.handle_error_window_expiry/2,
          &Service.Vendor.handle_error_per_minute_expiry/2,
          &Service.Vendor.handle_success_window_expiry/2
        ],
        vendor_config, vendor_map
      )
    end
    update_total_counter_in_background(service_name, vendor_code)
    vendor_code
  end

  @doc """
  Steps:
  1. Call the list of method over the provided vendor in

  parallel
  which returns a list of output of the form [{result, code},....].
  2. Get the required output from list of outputs pick_from_results.
  3. based on result:
      switch -> switch vendor in background(with new code ) and return the code
      no_switch -> return the vendor code
  """
  defp handle_conditions_in_parallel(list, vendor_config, vendor_map) do
    results = Spawn.Parallel.pmap_fx(list, vendor_config, vendor_map)
    {result, code} = pick_from_results(results)
    case result do
      :switch -> switch_vendor_in_background(vendor_config[:service_name], code, vendor_map)
                 code
      :no_switch -> code
    end
  end

  @doc """
  Method called if only entry exists in the list
  has {no_switch} then return code.
  """
  def pick_from_results([{:no_switch, code} | []]) do
    {:no_switch, code}
  end

  @doc """
  Steps:
  1. get the 1st entry in result.
  2. Check against different possible cases and return the result.
  """
  def pick_from_results([result | tail] = _) do
    case result do
      {:retry_switch, code} -> {:no_switch, code}
      {:skip_switch, code} -> {:no_switch, code}
      {:error_switch, code} -> {:switch, code}
      {:success_switch, code} -> {:switch, code}
      {:no_switch, _} -> pick_from_results(tail)
    end
  end

  @doc """
  Get the current retry counter value from redis
  decrement retry counter in background.
  check if retry counter is zero or less :reset and return {:retry_switch, vendor[:error_switch_code]}
  else return {:no_switch, vendor[:code]}
  """
  def handle_retry_expiry(vendor_config, vendor_map) do
    retry_counter = vendor_map[:retry_count]
    Logger.info("handle_retry_expiry  for #{vendor_config[:code]}| retry_counter #{retry_counter}")
    # decrement the counter in the background
    Logger.info("#{vendor_config[:code]} retry_counter #{retry_counter}")
    if retry_counter <= 0 do
      # reset the retry counter
      vendor_map = %{vendor_map | retry_count: vendor_config[:retry]}
      Task.async(fn -> DAO.DAOImpl.put_vendor(vendor_map) end)
      {:retry_switch, vendor_config[:error_switch_code]}
    else
      # return the current vendor code

      vendor_map = %{vendor_map | retry_count: retry_counter-1}
      DAO.DAOImpl.put_vendor(vendor_map)
      {:no_switch, vendor_config[:code]}
    end
  end

  @doc """
  Get the errors occurred current minute
  if errors occurred current minute is more than switch_epm:
    return {:error_switch, vendor[:error_switch_code]}
  else:
    {:no_switch, vendor[:code]}
  Get the number of errors occured for this minute and check against configuration
  and switch/no-switch based on it.
  """
  def handle_error_per_minute_expiry(vendor_config, vendor_map) do
    errors_per_minute = Util.CommonUtil.get_epm(vendor_config, vendor_map)
    Logger.info("handle_error_per_minute_expiry| Vendor: #{vendor_config[:code]}} |Error Per minute : #{errors_per_minute}")
    if errors_per_minute > vendor_config[:switch_epm] do
      {:error_switch, vendor_config[:error_switch_code]}
    else
      {:no_switch, vendor_config[:code]}
    end
  end

  @doc """
  Get the error window value for provided vendor.
  If error window is not expired:
    get the error counter for provided vendor from redis
    if error counter is greater than switch_error_count:
        switch_vendor in background with error_switch_code.
        return {:error_switch, vendor[:error_switch_code]}
  else :
    return {:no_switch, vendor[:code]}
  Summary: Checks for Error count in the provided error window.
  """
  def handle_error_window_expiry(vendor_config, vendor_map) do
    error_counter = Util.CommonUtil.get_error(vendor_config, vendor_map)
    Logger.info("error_counter #{error_counter}")
    if error_counter > vendor_config[:switch_error_count] do
      Logger.info(
        "Switching vendor to #{vendor_config[:error_switch_code]} as error_counter #{error_counter} has exceeded #{
          vendor_config[:switch_error_count]
        })"
      )
      {:error_switch, vendor_config[:error_switch_code]}
    else
      {:no_switch, vendor_config[:code]}
    end
  end
  @doc """
  Get the success window for Skip_back vendor.
  if success window for Skip_back vendor exists :
    if get success_counter for skip_back_vendor and compare with switch_success_count:
      return {:success_switch, skip_switch_code}
    else:
      handle_skip_back_case
  else:
    return {:no_switch, vendor[:code]}
  """

  def handle_success_window_expiry(vendor_config, vendor_map) do
    # success-window has not expired
    success_counter = Util.CommonUtil.get_success_counter(vendor_config, vendor_map)
    Logger.info("Success Counter  #{vendor_config[:code]} : #{success_counter}")
    if success_counter > vendor_config[:switch_success_count] do
      skip_switch_code = vendor_config[:skip_switch_code]
      Logger.info("Switching vendor to #{skip_switch_code}")
      {:success_switch, skip_switch_code}
    else
      handle_skipback_case(vendor_config, vendor_map)
    end
  end

  @doc """
  Async. get the vendor from ets based on vendor code and initialize
  the vendor.
  """
  defp switch_vendor_in_background(service_name, vendor_code, vendor_map) do
    ## background tasks
    Task.start(
      fn ->
        Logger.info("Switch vendor in background : #{vendor_map[:vendor]} -> #{vendor_code}")
        vendor_map = %{vendor_map | current: false}
        DAO.DAOImpl.put_vendor(vendor_map)
        get_vendor_from_ets(service_name, vendor_code)
            |> DAO.DAOImpl.initialize_vendor
      end
    )
  end

  @doc """
  Get the total counter( called times) for provided vendor
  check if the total counter is a multiple of skip_back_counter
  if yes:
    Async inc success_counter for switch_back_vendor and set switch_back_vendor as current vendor and return {:skip_switch, vendor[:skip_switch_code]}
  else:
    return {:no_switch, vendor[:code]}
  """
  def handle_skipback_case(vendor_config, vendor_map) do
    # check if the total counter is a multiple of skip_back_counter
    total_count = vendor_map[:total_count]
    if rem(total_count, vendor_config[:skip_back_counter]) == 0 do
      # yes, temporarily allow other vendor
      Logger.info("Handle_skip_back for #{vendor_config[:code]} ::: Incrementing vendor")
      # back-ground starts
      Task.async(
        fn ->
          success_count_val = vendor_map[:success_count]
          vendor_map = %{vendor_map | success_count: success_count_val+1}
          vendor_map = %{vendor_map | ov_in_action: true}
          DAO.DAOImpl.put_vendor(vendor_map)
        end
      )
      # back-ground ends
      {:skip_switch, vendor_config[:skip_switch_code]}
    else
      # no, continue with current vendor
      {:no_switch, vendor_config[:code]}
    end
  end

  @doc """
  Async get the vendor from ets and increment its total counter.
  """
  defp update_total_counter_in_background(service_name, vendor_code) do
    Task.async(
      fn ->
        vendor_map = DAO.DAOImpl.get_vendor(service_name, vendor_code)
        total_count_val = vendor_map[:total_count]
        vendor_map = %{vendor_map | total_count: total_count_val+1}
        DAO.DAOImpl.put_vendor(vendor_map)
      end
    )
  end

  defp background_work_for_other_vendor(vendor) do
    Task.async(
      fn ->
        DAO.DAOImpl.decr_success_counter_for_other_vendor(vendor)
      end
    )
    Task.async(
      fn ->
        DAO.DAOImpl.set_other_vendor_in_action(vendor, false)
      end
    )
  end

  @doc """
  Get the data for service_name-vendor_code in service_vendors
  table from ets.
  """
  def get_vendor_from_ets(service_name, vendor_code) do
    Logger.info("looking for #{service_name}-#{vendor_code}")
    # load vendor from ets
    [record | _] = :ets.lookup(:service_vendors, "#{service_name}-#{vendor_code}")
    elem(record, 1)
  end
end
