defmodule Service.Maker do
  @moduledoc false

  require Logger

  def init() do
    config = Application.get_env(:switch_over_service, __MODULE__)
    is_keydb_running = Application.get_env(:switch_over_service, :is_keydb_running)
    Logger.info("Is keydb_running : #{is_keydb_running}")
    :ets.new(:service_vendors, [:named_table, :public])
    :ets.insert_new(:service_vendors, {"is_keydb_running", is_keydb_running})
    global = config["global"]

    # load all vendors in the ETS
    Enum.map(config["services"], fn %{} = service -> load_vendors(service, global) end)

    # load primary vendors in the Redis
    Spawn.Parallel.pmap(
      :ets.match_object(:service_vendors, {:"$1", %{:primary => true}}),
      fn record -> DAO.DAOImpl.initialize_vendor(elem(record, 1)) end
    )
  end

  defp load_vendors(service, global) do
    vendor_code_list = Enum.map(service["vendors"], fn (vendor) -> vendor["code"] end)
    Logger.info("Vendor Code List = #{vendor_code_list}")
    :ets.insert_new(
      :service_vendors,
      {"#{service["name"]}-vendors", vendor_code_list}
    )
    vendors =
      load_vendors(service, global, service["vendors"])
  end

  defp load_vendors(
         %{"name" => service_name} = service,
         global,
         [
           %{
             "code" => code
           } = vendor
         | []] = _
       ) do
    code = vendor["code"]
    :ets.insert_new(
      :service_vendors,
      prepare_vendor_tuple(service_name, vendor, true, global)
    )
  end

  defp load_vendors(service, global, vendors) do
    service_name = service["name"]
    Enum.map(
      vendors,
      fn %{
           "code" => _,
           "error_switch_code" => _
         } = vendor ->
        :ets.insert_new(
          :service_vendors,
          prepare_vendor_tuple(service_name, vendor, false, global)
        )
      end
    )
  end

  def prepare_vendor_tuple(
        service_name,
        %{
          "code" => code
        } = vendor,
        sole_vendor,
        global
      ) do
    {
      "#{service_name}-#{code}",
      %{
        :service_name => service_name,
        :code => code,
        :error_switch_code => Map.get(vendor, "error_switch_code", nil),
        :skip_switch_code => Map.get(vendor, "skip_switch_code", nil),
        :sole_vendor => sole_vendor,
        :error_window => Map.get(vendor, "error_window", global["error_window"]),
        :success_window => Map.get(vendor, "success_window", global["success_window"]),
        :primary => Map.get(vendor, "primary", false),
        :retry => Map.get(vendor, "retry", global["retry"]),
        :skip_back_counter => Map.get(vendor, "skip_back_counter", global["skip_back_counter"]),
        :switch_error_count => Map.get(vendor, "switch_error_count", global["switch_error_count"]),
        :switch_success_count => Map.get(vendor, "switch_success_count", global["switch_success_count"]),
        :switch_epm => Map.get(vendor, "switch_epm", global["switch_epm"])
      }
    }
  end
end