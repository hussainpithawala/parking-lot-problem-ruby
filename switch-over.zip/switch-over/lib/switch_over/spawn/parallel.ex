defmodule Spawn.Parallel do
  @moduledoc false

  # Takes a function and applies it over a collection of arguments running in different processes
  def pmap(collection, func) do
    me = self()
    collection
    |> Enum.map(fn (elem) -> spawn_link fn -> (send me, {self(), func.(elem)}) end end)
    |> Enum.map(fn (pid) -> receive do {^pid, result} -> result end end)
  end

  def pmap(collection,arg2, func) do
    me = self()
    collection
    |> Enum.map(fn (elem) -> spawn_link fn -> (send me, {self(), func.(arg2,elem)}) end end)
    |> Enum.map(fn (pid) -> receive do {^pid, result} -> result end end)
  end

  # Takes a collection of functions and each function is separately called in a process with same argument
  def pmap_fx(collection, arg) do
    me = self()
    collection
    |> Enum.map(fn (func) -> spawn_link fn -> (send me, {self(), func.(arg)}) end end)
    |> Enum.map(fn (pid) -> receive do {^pid, result} -> result end end)
  end

  def pmap_fx(collection, arg1, arg2) do
    me = self()
    collection
    |> Enum.map(fn (func) -> spawn_link fn -> (send me, {self(), func.(arg1, arg2)}) end end)
    |> Enum.map(fn (pid) -> receive do {^pid, result} -> result end end)
  end
end
