defmodule Util.CommonUtil do
  require Logger

  def get_current_vendor(vendor_list) do
    Logger.info("Starting to find current vendor")
    req_vendor = Enum.find(vendor_list, fn vendor ->
      Logger.info("For #{vendor[:vendor]} -> Current value: #{vendor[:current]}")
      vendor[:current] == true
    end)
    Logger.info("Req vendor #{req_vendor[:vendor]}" )
    req_vendor
  end

  def get_error(vendorConfig, vendor) do
    error_epoch = vendor[:error_epoch]
    error_count = vendor[:error_count]
    is_window_expired = DAO.DBUtil.is_window_expired(error_epoch, vendorConfig[:error_window])
    Logger.info("Error count Window Expiry : #{is_window_expired}")
    if is_window_expired == true, do: 0, else: error_count
  end

  def get_epm(vendorConfig, vendor) do
    epm_epoch = vendor[:epm_epoch]
    epm_count = vendor[:epm_count]
    is_window_expired = DAO.DBUtil.is_window_expired(epm_epoch, 60)
    if is_window_expired == true, do: 0, else: epm_count
  end

  def get_success_counter(vendorConfig, vendor) do
    success_epoch = vendor[:success_epoch]
    success_count = vendor[:success_count]
    is_window_expired = DAO.DBUtil.is_window_expired(success_epoch, vendorConfig[:success_window])
    if is_window_expired == true, do: 0, else: success_count
  end

  def get_success_epoch(vendor_config, vendor) do
    is_window_expired = DAO.DBUtil.is_window_expired(vendor[:success_epoch], vendor_config[:success_window])
    if is_window_expired == true, do: DAO.DBUtil.get_current_epoch(), else: vendor[:success_epoch]
  end

  def get_error_epoch(vendor_config, vendor) do
    is_window_expired = DAO.DBUtil.is_window_expired(vendor[:error_epoch], vendor_config[:error_window])
    if is_window_expired == true, do: DAO.DBUtil.get_current_epoch(), else: vendor[:error_epoch]
  end

  def get_epm_epoch(vendor_config, vendor) do
    is_window_expired = DAO.DBUtil.is_window_expired(vendor[:epm_epoch], 60)
    if is_window_expired == true, do: DAO.DBUtil.get_current_epoch(), else: vendor[:epm_epoch]
  end
end