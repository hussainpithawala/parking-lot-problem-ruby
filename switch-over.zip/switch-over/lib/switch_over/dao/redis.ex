defmodule DAO.Redis do
  import UUID
  require Logger

  @moduledoc false
  @timeout 20

  def lock_and_initialize_vendor(vendor) do
    list = [
      &DAO.Redis.obtain_lock/1
    ]

    results = Spawn.Parallel.pmap_fx(list, vendor)
    if Enum.reduce(results, true, fn (x, acc) -> x && acc end) do
      Logger.info(
        "Starting vendor initialization after obtaining the lock and confirming that vendor: #{vendor[:code]}
        is not set as the current vendor for service: #{vendor[:service_name]}"
      )
      initialize_vendor(vendor)
    else
      Logger.info("Vendor Initialization is avoided, please check the logs for more details")
    end
  end

  def obtain_lock(vendor) do
    key = "initialize-#{vendor[:service_name]}"
    value = uuid4()
    conn = RedixPool.get_connection()
    redis_rep = Redix.command(conn,["SET", key, value, "NX", "PX", 500])
    if(elem(redis_rep, 0) == :error) do
      false
    else
      result = elem(redis_rep,1)
      case result do
        # unable to set the lock
        :nil -> Logger.info("Unable to set the #{key} with #{value} for vendor initialization")
                      false
        "OK" ->
          # able to set the lock, but check have we overridden someone else's lock, if so we cannot proceed forward
          # since another vendor might already be in action
          Logger.info("Key:#{key} is set with value:#{value} for vendor initialization")
          lock_response = Redix.command(conn, ["GET", key], %{ timeout: @timeout})
          if(elem(lock_response, 0) == :error) do
            false
          else
            lock_value = elem(lock_response, 1)
            if lock_value == value do
              Logger.info("Key:#{key} value:#{value} lock_value:#{lock_value} match success for vendor initialization")
              true
            else
              Logger.info("Key:#{key} value:#{value} lock_value:#{lock_value} match failed for vendor initialization")
              false
            end
          end
      end
    end
  end

  def initialize_vendor(vendor) do
    if !vendor[:primary] do
      init_keys_for_non_primary_vendor(vendor)
    else
      init_keys_for_primary_vendor(vendor)
    end
  end

  def init_keys_for_primary_vendor(vendorConfig) do
    vendorMap = %{service: vendorConfig[:service_name], vendor: vendorConfig[:code],
      primary: true, current: true,
      retry_count: vendorConfig[:retry],
      error_count: 0, error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0, epm_epoch: DAO.DBUtil.get_current_epoch(),
      success_count: 0, success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 0,ov_in_action: false}
    put_vendor(vendorMap)
  end

  def init_keys_for_non_primary_vendor(vendorConfig) do
    vendorMap = %{service: vendorConfig[:service_name], vendor: vendorConfig[:code],
      primary: false, current: true,
      retry_count: vendorConfig[:retry],
      error_count: 0, error_epoch: DAO.DBUtil.get_current_epoch(),
      epm_count: 0, epm_epoch: DAO.DBUtil.get_current_epoch(),
      success_count: 0, success_epoch: DAO.DBUtil.get_current_epoch(),
      total_count: 0,ov_in_action: false}
    put_vendor(vendorMap)
  end

  def put_vendor(vendorMap) do
    list=[ ["MULTI"],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "SERVICE_NAME", vendorMap[:service]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}","VENDOR", vendorMap[:vendor]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "PRIMARY", vendorMap[:primary]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "CURRENT", vendorMap[:current]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "OV_IN_ACTION", vendorMap[:ov_in_action]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "RETRY_COUNT", vendorMap[:retry_count]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "ERROR_COUNT", vendorMap[:error_count]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "ERROR_EPOCH", vendorMap[:error_epoch]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "EPM_COUNT", vendorMap[:epm_count]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "EPM_EPOCH", vendorMap[:epm_epoch]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "SUCCESS_COUNT", vendorMap[:success_count]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "SUCCESS_EPOCH", vendorMap[:success_epoch]],
      ["HSET", "#{vendorMap[:service]}-#{vendorMap[:vendor]}", "TOTAL_COUNT", vendorMap[:total_count]]
    ]
    conn = RedixPool.get_connection()
    redis_resp = Redix.pipeline(conn, list++[["EXEC"]], %{ timeout: @timeout})
    case redis_resp do
      {:error, _} -> :undefined
      {:ok, _} -> :ok
    end
  end

  def get_vendor(service_name, vendor_code) do
    conn = RedixPool.get_connection()
    redis_resp = Redix.command(conn, ["HGETALL", "#{service_name}-#{vendor_code}"], %{ timeout: @timeout})
    case redis_resp do
      {:error, _} -> :undefined
      {:ok, []} ->
        :nil
      {:ok,_} ->
        try do
          %{
            service: Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "SERVICE_NAME"], %{ timeout: @timeout}),
            vendor: Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "VENDOR"], %{ timeout: @timeout}),
            primary: WannabeBool.to_boolean(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "PRIMARY"], %{ timeout: @timeout})),
            current:  WannabeBool.to_boolean(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "CURRENT"], %{ timeout: @timeout})),
            retry_count: String.to_integer(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "RETRY_COUNT"], %{ timeout: @timeout})),
            error_count:  String.to_integer(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "ERROR_COUNT"], %{ timeout: @timeout})),
            error_epoch: String.to_integer(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "ERROR_EPOCH"], %{ timeout: @timeout})),
            ov_in_action: WannabeBool.to_boolean(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "OV_IN_ACTION"], %{ timeout: @timeout})),
            epm_count: String.to_integer(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "EPM_COUNT"], %{ timeout: @timeout})),
            epm_epoch: String.to_integer(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "EPM_EPOCH"], %{ timeout: @timeout})),
            success_count: String.to_integer(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "SUCCESS_COUNT"], %{ timeout: @timeout})),
            success_epoch: String.to_integer(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "SUCCESS_EPOCH"], %{ timeout: @timeout})),
            total_count: String.to_integer(Redix.command!(conn, ["HGET", "#{service_name}-#{vendor_code}", "TOTAL_COUNT"], %{ timeout: @timeout}))
          }
        rescue
          Redix.ConnectionError ->
            Logger.info("Failed to get vendor Redis #{service_name}-#{vendor_code} from Redis")
            :undefined
      end
    end
  end

  def get_all_vendors(service_name) do
    vendor_list = get_from_ets("#{service_name}-vendors")
    Logger.info("List of vendors : #{vendor_list}")
    vendor_detail_list = Spawn.Parallel.pmap(vendor_list, fn vendor_code -> DAO.Redis.get_vendor(service_name, vendor_code) end)
    vendor_list_final = if Enum.member?(vendor_detail_list, :undefined) do
      :undefined
    else
      vendor_list = Enum.filter(vendor_detail_list, fn vendor ->
        vendor != :nil
      end)
      case vendor_list do
        [] -> :nil
        _ -> vendor_list
      end
    end
  end

  def get_experiment_entry(function, scheme) do
    conn = RedixPool.get_connection()
    redis_resp = Redix.command(conn, ["HGETALL", "experiment-#{function}-#{scheme}"], %{ timeout: @timeout})
    case redis_resp do
      {:error, _} -> :undefined
      {:ok, []} ->
        :nil
      {:ok,_} ->
        try do
          %{
            category: "experiment-#{function}",
            scheme: scheme,
            wf_count: String.to_integer(Redix.command!(conn, ["HGET", "experiment-#{function}-#{scheme}", "WF_COUNT"], %{ timeout: @timeout})),
            wf_config_count:  String.to_integer(Redix.command!(conn,
              ["HGET", "experiment-#{function}-#{scheme}", "WF_CONFIG_COUNT"], %{ timeout: @timeout})),
            cur_impl: Redix.command!(conn, ["HGET", "experiment-#{function}-#{scheme}", "CUR_IMPL"], %{ timeout: @timeout}),
            exp_impl: Redix.command!(conn, ["HGET", "experiment-#{function}-#{scheme}", "EXP_IMPL"], %{ timeout: @timeout})
          }
        rescue
          Redix.ConnectionError ->
            Logger.info("Failed to get vendor Redis from Redis")
            :undefined
        end
    end
  end

  def set_experiment_entry(experiment_map) do
    list=[ ["MULTI"],
      ["HSET", "#{experiment_map[:category]}-#{experiment_map[:scheme]}", "WF_COUNT", experiment_map[:wf_count]],
      ["HSET", "#{experiment_map[:category]}-#{experiment_map[:scheme]}","WF_CONFIG_COUNT", experiment_map[:wf_config_count]],
      ["HSET", "#{experiment_map[:category]}-#{experiment_map[:scheme]}","CUR_IMPL", experiment_map[:cur_impl]],
      ["HSET", "#{experiment_map[:category]}-#{experiment_map[:scheme]}","EXP_IMPL", experiment_map[:exp_impl]]
    ]
    conn = RedixPool.get_connection()
    redis_resp = Redix.pipeline(conn, list++[["EXEC"]], %{ timeout: @timeout})
    case redis_resp do
      {:error, _} -> :undefined
      {:ok, _} -> :ok
    end
  end

  def get_from_ets(key) do
    Logger.info("looking for #{key}")
    # load vendor from ets
    [record | _] = :ets.lookup(:service_vendors, "#{key}")
    elem(record, 1)
  end

end
