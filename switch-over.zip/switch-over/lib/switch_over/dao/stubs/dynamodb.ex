defmodule DAO.DynamoDBTest do
  require Logger

  def get_item(property) do
    Logger.info("DynamoDBTest | get_item | #{property}")
    case property do
      "pan_service--OV" -> %{"value" => %{"S" => :undefined}, "epoch" => %{"N" => "0"}}
      "pan_service-v1-OV" -> %{"value" => %{"S" => true}, "epoch" => %{"N" => "0"}}
      "pan_service-v1-OV" -> %{"value" => %{"S" => :undefined}, "epoch" => %{"N" => "0"}}
      "pan_service-v1-RTC" -> %{"value" => %{"S" => "3"}, "epoch" => %{"N" => "0"}}
      "pan_service-v2-RTC" -> %{"value" => %{"S" => "0"}, "epoch" => %{"N" => "0"}}
      "pan_service-v2-EC" -> %{"value" => %{"S" => "10"} , "epoch" => %{"N" => to_string(get_current_epoch())}}
      "pan_service-v1-EC" -> %{"value" => %{"S" => "0"} , "epoch" => %{"N" => "0"}}
      "pan_service-v2-TC" -> %{"value" => %{"S" => "10"} , "epoch" => %{"N" => to_string(get_current_epoch())}}
      "pan_service-v1-TC" -> %{"value" => %{"S" => "9"} , "epoch" => %{"N" => to_string(get_current_epoch())}}
      "pan_service-v1-EC" ->  %{"value" => %{"S" => "0"}, "epoch" => %{"N" => "0"}}
      "pan_service-v2-EPM" ->  %{"value" => %{"S" => "10"}, "epoch" => %{"N" => to_string(get_current_epoch)}}
      "pan_service-v1-EPM" ->  %{"value" => %{"S" => "0"}, "epoch" => %{"N" => "0"}}
      "pan_service-v1-SC" -> %{"value" => %{"S" => "10"}, "epoch" => %{"N" => to_string(get_current_epoch())}}
      _ -> %{"value" => %{"S" => "v1"}, "epoch" => %{"N" => "0"}}
    end
  end

  def put_item(item_map) do
    true
  end

  def get_item(service_name, vendor_code) do
    if(service_name == "experiment") do
      case vendor_code do
        "PLCREDI" -> %{
                        "SERVICE_NAME" => %{"S" => "experiment"},
                        "VENDOR" => %{"S" => "PLCREDI"},
                        "WF_CONFIG_COUNT" => %{"N" => "10"},
                        "WF_COUNT" => %{"N" => "9"},
                        "CUR_IMPL" => %{"S" => "Elastit"},
                        "EXP_IMPL" => %{"S" => "Workflow"}
                      }
        "PL_LOC" -> %{
                      "SERVICE_NAME" => %{"S" => "experiment"},
                      "VENDOR" => %{"S" => "PLCREDI"},
                      "WF_CONFIG_COUNT" => %{"N" => "10"},
                      "WF_COUNT" => %{"N" => "9"},
                      "CUR_IMPL" => %{"S" => "Elastit"},
                      "EXP_IMPL" => %{"S" => "Workflow"}
                    }
        "PLCREDI2" -> %{
                        "SERVICE_NAME" => %{"S" => "experiment"},
                        "VENDOR" => %{"S" => "PLCREDI2"},
                        "WF_CONFIG_COUNT" => %{"N" => "10"},
                        "WF_COUNT" => %{"N" => "10"},
                        "CUR_IMPL" => %{"S" => "Elastit"},
                        "EXP_IMPL" => %{"S" => "Workflow"}
                      }
        "PL_CREDI" -> %{
                        "SERVICE_NAME" => %{"S" => "experiment"},
                        "VENDOR" => %{"S" => "PLCREDI"},
                        "WF_CONFIG_COUNT" => %{"N" => "0"},
                        "WF_COUNT" => %{"N" => "9"},
                        "CUR_IMPL" => %{"S" => "Elastit"},
                        "EXP_IMPL" => %{"S" => "Workflow"}
                      }
      end
    else
      %{
        "SERVICE_NAME" => %{"S" => "pan_service"},
        "VENDOR" => %{"S" => "NSDL"},
        "PRIMARY" => %{"BOOL" => true},
        "CURRENT" => %{"BOOL" => true},
        "OV_IN_ACTION" => %{"BOOL" => false},
        "RETRY_COUNT" => %{"N" => "10"},
        "ERROR_COUNT" => %{"N" => "0"},
        "ERROR_EPOCH" => %{"N" => "0"},
        "EPM_COUNT" => %{"N" => "0"},
        "EPM_EPOCH" => %{"N" => "0"},
        "SUCCESS_COUNT" => %{"N" => "0"},
        "SUCCESS_EPOCH" => %{"N" => "0"},
        "TOTAL_COUNT" => %{"N" => "0"}
      }
    end
  end


  def list_items(service_name) do
    [%{
      "SERVICE_NAME" => %{"S" => "pan_service"},
      "VENDOR" => %{"S" => "NSDL"},
      "PRIMARY" => %{"BOOL" => true},
      "CURRENT" => %{"BOOL" => true},
      "OV_IN_ACTION" => %{"BOOL" => false},
      "RETRY_COUNT" => %{"N" => "10"},
      "ERROR_COUNT" => %{"N" => "0"},
      "ERROR_EPOCH" => %{"N" => "0"},
      "EPM_COUNT" => %{"N" => "0"},
      "EPM_EPOCH" => %{"N" => "0"},
      "SUCCESS_COUNT" => %{"N" => "0"},
      "SUCCESS_EPOCH" => %{"N" => "0"},
      "TOTAL_COUNT" => %{"N" => "0"}
    }]
  end

  def put_item_if_not_exists(property_map) do
    true
  end

  def delete_item(property) do
    true
  end

  def get_current_epoch() do
      {:ok, current_date_time} = DateTime.now("Etc/UTC")
      DateTime.to_unix(current_date_time)
  end

  def get_experiment_entry(function, scheme) do
    if(function == "experiment") do
      case scheme do
        "PL_LOC" -> %{
                      "SERVICE_NAME" => "experiment",
                      "VENDOR" => "PL_LOC",
                      "WF_CONFIG_COUNT" => 1,
                      "WF_COUNT" => 1,
                      "EXP_IMPL" => "Workflow",
                      "CUR_IMPL" => "Elastit"
                    }
        "PLCREDI2" -> %{
                       "SERVICE_NAME" => "experiment",
                       "VENDOR" => "PL_CREDI2",
                       "WF_CONFIG_COUNT" => 2,
                       "WF_COUNT" => 2,
                       "EXP_IMPL" => "Workflow",
                       "CUR_IMPL" => "Elastit"
                     }
        "PL_CREDI" -> %{
                        "SERVICE_NAME" => "experiment",
                        "VENDOR" => "PL_CREDI",
                        "WF_CONFIG_COUNT" => 0,
                        "WF_COUNT" => 1,
                        "EXP_IMPL" => "Workflow",
                        "CUR_IMPL" => "Elastit"
                      }
      end
    end
  end

end