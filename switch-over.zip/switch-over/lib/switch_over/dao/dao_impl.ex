defmodule DAO.DAOImpl do
  @moduledoc false
  require Logger
  alias DAO.DB, as: DB
  alias DAO.Redis, as: Redis

  def initialize_vendor(vendor) do
    is_locked= DB.initialize_vendor(vendor)
    redis_response = Redis.lock_and_initialize_vendor(vendor)
      case redis_response do
        :undefined ->
          Logger.info("Failed to initialize vendor in redis")
          update_keydb_entry(false)
        :nil ->
          Logger.info("Failed to initialize vendor in redis")
          verify_and_take_snapshot_from_DB_to_cache()
          DB.delete_lock(vendor)
        _ ->
          Logger.info("Success to initialize vendor in redis")
          DB.delete_lock(vendor)
      end

  end

  def verify_and_take_snapshot_from_DB_to_cache() do
    is_keydb_running = get_keydb_entry()
    if !is_keydb_running do
        apply_snapshot()
        update_keydb_entry(true)
    end
  end


#  Apply snapshot from DynamoDB to keydb
  def apply_snapshot() do
    Logger.info("Taking Snapshot DB -> keyDB")
    vendor_response_list = DB.scan_table()
    Enum.map(vendor_response_list,
      fn vendor ->
        if(vendor["SERVICE_NAME"]["S"] == "experiment") do
          exp_map = DAO.DBUtil.generate_experiment_map(vendor)
          Redis.set_experiment_entry(exp_map)
        else
          vendor_map = DAO.DBUtil.generate_vendor_map_from_db_json(vendor)
          Redis.put_vendor(vendor_map)
        end

      end)
  end

  def get_vendor(service_name, vendor_code) do
    redis_response = Redis.get_vendor(service_name, vendor_code)
    case redis_response do
      :undefined ->
        Logger.info("Failed to get vendor from redis")
        update_keydb_entry(false)
        DB.get_vendor(service_name, vendor_code)
      :nil ->
        Logger.info("Failed to get vendor in redis but Redis is up")
        verify_and_take_snapshot_from_DB_to_cache()
        DB.get_vendor(service_name, vendor_code)
      _  ->
        Logger.info("Successfully got vendor from redis")
        redis_response
    end
  end

  def put_vendor(vendor_map) do
    resp = Redis.put_vendor(vendor_map)
    Task.start(fn  ->
      Logger.info("Putting vendor in DB for #{vendor_map[:vendor]} -->  Current value : #{vendor_map[:current]}")
      DB.put_vendor(vendor_map) end)
    case resp do
      :undefined ->
        Logger.info("Failed to put vendor in redis")
        update_keydb_entry(false)
      :nil ->
        Logger.info("Failed to put vendor in redis but redis is up")
        verify_and_take_snapshot_from_DB_to_cache()
      _ -> Logger.info("Successfully put vendor")
    end
  end

  def get_all_vendors_for_provided_service(service_name) do
    redis_response = Redis.get_all_vendors(service_name)
    case redis_response do
      :undefined ->
        Logger.info("Failed to get all vendors from redis")
        update_keydb_entry(false)
        DB.get_all_vendors_for_given_service(service_name)
      :nil ->
        Logger.info("Failed to get all vendors from redis but redis is up")
        verify_and_take_snapshot_from_DB_to_cache()
        DB.get_all_vendors_for_given_service(service_name)
      _ ->
        Logger.info("Successfully received vendors from redis")
        redis_response
    end
  end

  def get_experiment_entry(function, scheme) do
    redis_response = Redis.get_experiment_entry(function, scheme)
    case redis_response do
      :undefined ->
        Logger.info("Failed to get vendor from redis")
        update_keydb_entry(false)
        DB.get_experiment_entry(function, scheme)
      :nil ->
        Logger.info("Failed to get vendor in redis but Redis is up")
        verify_and_take_snapshot_from_DB_to_cache()
        DB.get_experiment_entry(function, scheme)
      _  ->
        Logger.info("Successfully got vendor from redis")
        redis_response
    end
  end

  def set_experiment_entry(experiment_map) do
    resp = Redis.set_experiment_entry(experiment_map)
    Task.start(fn  ->
      DB.set_experiment_entry(experiment_map) end)
    case resp do
      :undefined ->
        Logger.info("Failed to put vendor in redis")
        update_keydb_entry(false)
      :nil ->
        Logger.info("Failed to put vendor in redis but redis is up")
        verify_and_take_snapshot_from_DB_to_cache()
      :ok ->
        Logger.info("Successfully put vendor")
    end
    true
  end

  defp update_keydb_entry(is_keydb_running) do
    :ets.insert(
      :service_vendors,
      {"is_keydb_running", is_keydb_running}
    )
  end

  defp get_keydb_entry() do
    [record | _] = :ets.lookup(:service_vendors, "is_keydb_running")
    elem(record, 1)
  end

end


