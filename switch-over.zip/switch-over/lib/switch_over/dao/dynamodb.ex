defmodule DAO.DynamoDB do
  require Logger

  defp get_aws_client() do
    accessKey = Application.get_env(:aws,:accessKey)
    secretAccessKey = Application.get_env(:aws,:secretAccessKey)
    region = Application.get_env(:aws,:region)
    aws_client = AWS.Client.create(accessKey, secretAccessKey, region)
  end


  defp get_property_table_name() do
    Application.get_env(:aws,:propertyTable)
  end

  @doc """
  get item by providing primary key.
  It returns item if successful call else return empty map
  """
  def get_item(property) do
    get_item_output = AWS.DynamoDB.get_item(get_aws_client(), %{
      "TableName"  => get_property_table_name(),
      "Key" => %{
        "property" => %{
          "S" => property
        }
      }
    })
    case elem(get_item_output,0) do
      :ok -> extract_item_if_present(get_item_output)
      :error -> %{"value" => %{"S" => :undefined}, "epoch" => %{"N" => "0"}}
    end
  end


  def get_item(service_name, vendor_code) do
    get_item_output = AWS.DynamoDB.get_item(get_aws_client(), %{
      "TableName"  => get_property_table_name(),
      "Key" => %{
        "SERVICE_NAME" => %{
          "S" => service_name
        },
        "VENDOR" => %{
          "S" => vendor_code
        }
      }
    })
    case elem(get_item_output,0) do
      :ok -> elem(get_item_output, 1)["Item"]
      :error -> :undefined
    end
  end

  def list_items(service_name) do
    get_item_output = AWS.DynamoDB.query(get_aws_client(), %{
      "TableName"  => get_property_table_name(),
      "KeyConditionExpression" => "SERVICE_NAME = :service_name",
      "ExpressionAttributeValues" => %{
        ":service_name" => %{
          "S" => service_name
        }
      }
    })
    #    Logger.info("list Items: #{get_item_output}")
    case elem(get_item_output,0) do
      :ok -> elem(get_item_output, 1)["Items"]
      :error -> :undefined
    end
  end

  def query_current_item(service_name) do
    get_item_output = AWS.DynamoDB.query(get_aws_client(), %{
      "TableName"  => get_property_table_name(),
      "KeyConditionExpression" => "SERVICE_NAME = :service_name and IS_CURRENT = :current",
      "ExpressionAttributeValues" => %{
        ":service_name" => %{
          "S" => service_name
        },
        ":current" => %{
          "BOOL" => true
        }
      }
    })
    Logger.info("list Items: #{get_item_output}")
    case elem(get_item_output,0) do
      :ok -> elem(get_item_output, 1)["Items"][0]
      :error -> :undefined
    end
  end


  defp extract_item_if_present(output) do
    result_map = elem(output, 1)
    Logger.info("extracting vendor")
    case Map.has_key?(result_map,"Item") do
      false -> %{"value" => %{"S" => :undefined}, "epoch" => %{"N" => "0"}}
      true -> result_map["Item"]
    end

  end

  @doc """
  Put item by providing data.
  Return true if success else false
  """
  def put_item(item_map) do
    put_item_output = AWS.DynamoDB.put_item(get_aws_client(), %{
      "TableName"  => get_property_table_name(),
      "Item" => item_map
    })
    case elem(put_item_output,0) do
      :ok -> true
      :error -> false
    end
  end

  @doc """
  Put item if attribute not exists by providing data.
  Return true if success else false
  """
  def put_item_if_not_exists(property_map) do
#    Logger.info("Property map : #{property_map}")
    put_item_output = AWS.DynamoDB.put_item(get_aws_client(), %{
      "TableName"  => get_property_table_name(),
      "ConditionExpression" => "attribute_not_exists(#r)",
      "ExpressionAttributeNames" => %{"#r": "VENDOR"},
      "Item" => property_map
    })
    case elem(put_item_output,0) do
      :ok -> true
      :error -> false
    end
  end

  @doc """
  Delete item by providing data.
  Return true if success else false
  """
  def delete_item(service_name, vendor) do
    item_deleted_output = AWS.DynamoDB.delete_item(get_aws_client(),  %{
      "TableName"  => get_property_table_name(),
      "Key" => %{
        "SERVICE_NAME" => %{
          "S" => service_name
        },
        "VENDOR" => %{
          "S" => vendor
        }
      }
    })
    case elem(item_deleted_output,0) do
      :ok -> true
      :error -> false
    end
  end

  def scan_table() do
    scanned_output = AWS.DynamoDB.scan(get_aws_client(), %{
    "TableName" => get_property_table_name()
    })
    case elem(scanned_output,0) do
      :ok -> elem(scanned_output, 1)["Items"]
      :error -> :undefined
    end
  end


end