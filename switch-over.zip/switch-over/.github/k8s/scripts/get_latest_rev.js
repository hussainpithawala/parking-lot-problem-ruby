var items = require('./output').items;
console.log(items[items.length - 1].metadata.name);