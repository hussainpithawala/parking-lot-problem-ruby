var items = require('./output').items;

var list = "";
for (var i = 0; i < items.length - 1; i++) {
    list += items[i].metadata.name + " ";
}

console.log(list);
