import http from 'k6/http';
import {check, sleep} from "k6";
import {Rate} from "k6/metrics";

export let errorRate = new Rate("errors");
export let options = {
    stages: [
        {duration: '1m', target: 30}, // below normal load
        {duration: '3m', target: 30},
        {duration: '2m', target: 60}, // normal load
        {duration: '3m', target: 60},
        {duration: '2m', target: 120}, // around the breaking point
        {duration: '3m', target: 120},
        {duration: '5m', target: 0}, // scale down. Recovery stage.
    ],
    thresholds: {
        // fail the test if 85th percentile response goes above 2000ms
        http_req_duration: ["p(85)<2000"],
        errors: ["rate<0.2"]
    }
};

export default function () {
    const BASE_URL = 'https://switch-over.prod.incred.com'; // make sure this is not production
    let req = {
        method: 'POST',
        url:  `${BASE_URL}/validate`,
        body:  JSON.stringify({
            docType: '2',
            docNumber: 'CZCPA9469G'
        }),
        params:{
            headers: { 'Content-Type': 'application/json' },
        },
    };
    let batchResponses = http.batch([
        req
    ]);

    for (const key in batchResponses) {
        let result = check(
            batchResponses[key], {
                "status was 200": r => batchResponses[key].status === 200
            });
        //console.log(JSON.stringify(batchResponses[key]))
        errorRate.add(!result);
    }
    sleep(1);
}
