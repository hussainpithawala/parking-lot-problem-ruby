# Execute this script using command "sh build_docker_image.sh {ENV} {GIT_TOKEN}" providing ENV and GIT_TOKEN values
export MIX_ENV=$1
export GIT_TOKEN=$2
docker build --build-arg GIT_TOKEN=$GIT_TOKEN --build-arg ENV=$MIX_ENV . --file Dockerfile --tag switch-over:1.0